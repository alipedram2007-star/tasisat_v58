/* سیستم مدیریت پرسنل — فرانت‌اند (بهینه‌سازی سرعت منوها) */
let meta = { personal: [], work: [] };
let currentId = null;
let currentWorkId = null;
let selectedWorkId = null;
/** انتخاب‌های چک‌باکس جدول اصلی پرسنل (برای تولید گروهی کارت) */
let selectedCardIds = new Set();

/** کاربر جاری و توکن احراز هویت */
const AUTH_TOKEN_KEY = 'tasisat_auth_token';
let currentUser = null;

function getAuthToken() {
  return localStorage.getItem(AUTH_TOKEN_KEY) || '';
}
function setAuthToken(token) {
  if (token) localStorage.setItem(AUTH_TOKEN_KEY, token);
  else localStorage.removeItem(AUTH_TOKEN_KEY);
}
function isAdmin() {
  return currentUser && currentUser.role === 'admin';
}
function isCustomUser() {
  return currentUser && currentUser.role === 'custom';
}
/** بررسی دسترسی — مدیر همه؛ عادی فقط card/export؛ سفارشی طبق لیست */
function hasPerm(perm) {
  if (!currentUser) return false;
  if (currentUser.role === 'admin') return true;
  if (currentUser.role === 'user') {
    return perm === 'card_issue' || perm === 'export_excel';
  }
  if (currentUser.role === 'custom') {
    const perms = currentUser.permissions || [];
    return perms.indexOf(perm) >= 0;
  }
  return false;
}
function isLoggedIn() {
  return Boolean(getAuthToken() && currentUser);
}

/** تعریف دسترسی‌ها برای فرم کاربر سفارشی */
const PERMISSION_DEFS = [
  { key: 'personnel_create', label: 'ایجاد پرسنل جدید' },
  { key: 'personnel_edit', label: 'ویرایش پرسنل' },
  { key: 'personnel_delete', label: 'حذف پرسنل' },
  { key: 'photo_manage', label: 'آپلود و حذف عکس' },
  { key: 'work_write', label: 'مدیریت سوابق کاری (افزودن/ویرایش/حذف)' },
  { key: 'import_excel', label: 'ایمپورت اکسل' },
  { key: 'export_excel', label: 'خروجی اکسل' },
  { key: 'card_issue', label: 'صدور کارت (تکی و گروهی)' },
  { key: 'invalid_imports', label: 'مدیریت ردیف‌های نامعتبر' },
];

/**
 * شروع دانلود از لینک موقت سرور (بدون Blob)
 * این روش با مرورگر و دانلود‌منیجر سازگار است چون یک URL واقعی است.
 */
function triggerDownloadLink(downloadUrl, filename) {
  if (!downloadUrl) throw new Error('لینک دانلود دریافت نشد');
  const a = document.createElement('a');
  a.href = downloadUrl;
  if (filename) a.download = filename;
  a.rel = 'noopener';
  a.style.display = 'none';
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    try { document.body.removeChild(a); } catch (_) {}
  }, 1000);
}

/**
 * پردازش پاسخ API برای دانلود:
 * - اگر JSON با download_url باشد → لینک موقت را باز می‌کند (روش اصلی)
 * - اگر بدنه PDF/فایل باینری باشد → با Blob دانلود می‌کند (سازگاری با سرور قدیمی)
 */
async function downloadFromApiResponse(res, fallbackError, fallbackFilename) {
  if (!res.ok) {
    let msg = fallbackError || 'خطا در دریافت فایل';
    try {
      const err = await res.json();
      msg = err.detail || msg;
    } catch (_) {}
    throw new Error(typeof msg === 'string' ? msg : JSON.stringify(msg));
  }

  const ctype = (res.headers.get('content-type') || '').toLowerCase();

  // مسیر اصلی: سرور لینک موقت برمی‌گرداند
  if (ctype.includes('application/json')) {
    const data = await res.json();
    // پیام خطای قدیمی «خروجی PDF نیست» دیگر اینجا نباید بیاید
    if (data && data.download_url) {
      triggerDownloadLink(data.download_url, data.filename || fallbackFilename || '');
      return data;
    }
    if (data && data.detail) {
      throw new Error(typeof data.detail === 'string' ? data.detail : JSON.stringify(data.detail));
    }
    throw new Error('پاسخ سرور لینک دانلود ندارد. مطمئن شوید main.py و app.js هر دو به‌روز شده‌اند.');
  }

  // سازگاری با سرور قدیمی که مستقیماً PDF/فایل می‌فرستد
  if (ctype.includes('application/pdf') || ctype.includes('octet-stream') || ctype.includes('spreadsheet')) {
    const blob = await res.blob();
    const name = fallbackFilename || (ctype.includes('sheet') ? 'export.xlsx' : 'download.pdf');
    const mime = ctype.includes('sheet')
      ? 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
      : (ctype.includes('pdf') ? 'application/pdf' : blob.type || 'application/octet-stream');
    const typed = blob.type === mime ? blob : new Blob([blob], { type: mime });
    const url = URL.createObjectURL(typed);
    const a = document.createElement('a');
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    return { filename: name };
  }

  // تلاش آخر: شاید JSON بدون content-type درست
  const buf = await res.arrayBuffer();
  const head = new TextDecoder('utf-8').decode(buf.slice(0, 64)).trim();
  if (head.startsWith('{')) {
    try {
      const data = JSON.parse(new TextDecoder('utf-8').decode(buf));
      if (data && data.download_url) {
        triggerDownloadLink(data.download_url, data.filename || fallbackFilename || '');
        return data;
      }
      if (data && data.detail) {
        throw new Error(typeof data.detail === 'string' ? data.detail : JSON.stringify(data.detail));
      }
    } catch (e) {
      if (e && e.message && !e.message.includes('JSON')) throw e;
    }
  }
  // اگر امضای PDF باشد
  const bytes = new Uint8Array(buf);
  if (bytes[0] === 0x25 && bytes[1] === 0x50 && bytes[2] === 0x44 && bytes[3] === 0x46) {
    const typed = new Blob([buf], { type: 'application/pdf' });
    const url = URL.createObjectURL(typed);
    const a = document.createElement('a');
    a.href = url;
    a.download = fallbackFilename || 'card.pdf';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    return { filename: fallbackFilename || 'card.pdf' };
  }

  throw new Error(
    (fallbackError || 'خطا در دریافت فایل') +
    ' — احتمالاً فایل app.js یا main.py به‌روز نشده. سرور را ریستارت و Ctrl+F5 بزنید.'
  );
}

/** fetch با توکن احراز هویت */
async function apiFetch(url, options = {}) {
  const opts = { ...options };
  const headers = new Headers(opts.headers || {});
  const token = getAuthToken();
  if (token) headers.set('X-Auth-Token', token);
  if (opts.body && !(opts.body instanceof FormData) && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }
  opts.headers = headers;
  const res = await fetch(url, opts);
  if (res.status === 401) {
    setAuthToken('');
    currentUser = null;
    showLoginScreen();
    throw new Error('نشست منقضی شده — دوباره وارد شوید');
  }
  return res;
}

function showLoginScreen() {
  document.getElementById('loginScreen')?.classList.remove('d-none');
  document.getElementById('appRoot')?.classList.add('d-none');
  document.body.classList.remove('role-admin', 'role-user', 'role-custom');
}
function showAppScreen() {
  document.getElementById('loginScreen')?.classList.add('d-none');
  document.getElementById('appRoot')?.classList.remove('d-none');
  document.body.classList.toggle('role-admin', isAdmin());
  document.body.classList.toggle('role-user', currentUser && currentUser.role === 'user');
  document.body.classList.toggle('role-custom', isCustomUser());
  const badge = document.getElementById('currentUserBadge');
  if (badge && currentUser) {
    const labels = { admin: 'مدیر', user: 'عادی', custom: 'سفارشی' };
    const label = labels[currentUser.role] || currentUser.role_label || currentUser.role;
    badge.textContent = `${currentUser.username} (${label})`;
    badge.className = isAdmin()
      ? 'badge bg-success'
      : isCustomUser()
        ? 'badge bg-warning text-dark'
        : 'badge bg-info text-dark';
  }
  applyRoleUi();
}

function applyRoleUi() {
  // نمایش/مخفی‌سازی بر اساس دسترسی‌های گزینشی
  const map = [
    { sel: '#btnNewPerson, [onclick*="openNewForm"]', perm: 'personnel_create' },
    { sel: '#btnImportExcel', perm: 'import_excel' },
    { sel: '#btnExportExcel', perm: 'export_excel' },
  ];
  map.forEach(({ sel, perm }) => {
    document.querySelectorAll(sel).forEach((el) => {
      el.classList.toggle('d-none', !hasPerm(perm));
    });
  });
  // مدیریت کاربران فقط مدیر
  document.querySelectorAll('.admin-only-strict, [onclick*="openUsersModal"]').forEach((el) => {
    const li = el.closest('li') || el;
    if (!isAdmin()) li.classList.add('d-none');
    else li.classList.remove('d-none');
  });
}

async function handleLogin(e) {
  e.preventDefault();
  const username = (document.getElementById('loginUsername').value || '').trim();
  const password = document.getElementById('loginPassword').value || '';
  const errEl = document.getElementById('loginError');
  errEl.classList.add('d-none');
  const btn = document.getElementById('btnLogin');
  btn.disabled = true;
  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.detail || 'ورود ناموفق');
    setAuthToken(data.token);
    currentUser = data.user;
    showAppScreen();
    await bootApp();
  } catch (err) {
    errEl.textContent = err.message || 'خطا در ورود';
    errEl.classList.remove('d-none');
  } finally {
    btn.disabled = false;
  }
  return false;
}

async function handleLogout() {
  try {
    await apiFetch('/api/auth/logout', { method: 'POST' });
  } catch (_) {}
  setAuthToken('');
  currentUser = null;
  showLoginScreen();
  document.getElementById('loginPassword').value = '';
}

async function restoreSession() {
  const token = getAuthToken();
  if (!token) {
    showLoginScreen();
    return false;
  }
  try {
    const res = await fetch('/api/auth/me', {
      headers: { 'X-Auth-Token': token },
    });
    if (!res.ok) {
      setAuthToken('');
      showLoginScreen();
      return false;
    }
    currentUser = await res.json();
    showAppScreen();
    return true;
  } catch (_) {
    setAuthToken('');
    showLoginScreen();
    return false;
  }
}

let _personModalInst = null;
const personModal = () => {
  if (!_personModalInst) {
    _personModalInst = bootstrap.Modal.getOrCreateInstance(document.getElementById('personModal'));
  }
  return _personModalInst;
};

// ─── تقویم جلالی — init تنبل (فقط هنگام focus) برای سرعت باز شدن فرم ───
function isJalaliField(f) {
  const label = String(f.label || '');
  return Boolean(f.is_date || label.includes('تاریخ') || label.includes('اعتبار'));
}

const _jalaliOpts = {
  calendarType: 'persian',
  initialValue: false,
  initialValueType: 'persian',
  format: 'YYYY/MM/DD',
  persianDigit: false,
  observer: false,
  autoClose: true,
  responsive: true,
  calendar: {
    persian: { locale: 'fa', showHint: false, leapYearMode: 'algorithmic' }
  },
  toolbox: {
    enabled: true,
    todayButton: { enabled: true, text: { fa: 'امروز', en: 'Today' } },
    submitButton: { enabled: false },
    calendarSwitch: { enabled: false }
  }
};

function ensureJalaliPicker(el) {
  if (!el || !window.jQuery || !jQuery.fn.persianDatepicker) return;
  // فیلد قفل‌شده (تمدید قبلی) — تقویم باز نشود
  if (el.disabled || el.readOnly || el.dataset.locked === '1') return;
  if (el.dataset.pdReady === '1') return;
  const existing = (el.value || '').trim();
  try {
    jQuery(el).persianDatepicker({
      ..._jalaliOpts,
      initialValue: !!existing,
    });
    el.dataset.pdReady = '1';
    if (existing && el.value !== existing) el.value = existing;
  } catch (_) {}
}

/** قفل کردن فیلد تاریخ (جلوگیری از ویرایش و باز شدن تقویم) */
function lockDateField(el, locked) {
  if (!el) return;
  if (locked) {
    el.readOnly = true;
    el.disabled = true;
    el.dataset.locked = '1';
    el.classList.add('bg-light', 'text-muted');
    el.style.cursor = 'not-allowed';
    // اگر تقویم قبلاً به این فیلد وصل شده، آن را از بین ببر
    if (el.dataset.pdReady === '1' && window.jQuery) {
      try {
        const $el = jQuery(el);
        if ($el.data('datepicker')) {
          $el.data('datepicker').hide();
          $el.data('datepicker').destroy();
        }
        $el.off('.pwt');
      } catch (_) {}
      delete el.dataset.pdReady;
    }
  } else {
    el.readOnly = false;
    el.disabled = false;
    delete el.dataset.locked;
    el.classList.remove('bg-light', 'text-muted');
    el.style.cursor = '';
  }
}

/** فقط listener فوکوس — بدون destroy/recreate سنگین روی همه فیلدها */
function bindLazyJalaliPickers(scope = document) {
  if (!scope) return;
  scope.querySelectorAll('input.jalali-date').forEach((el) => {
    if (el.dataset.lazyBound) return;
    el.dataset.lazyBound = '1';
    el.addEventListener('focus', () => ensureJalaliPicker(el), { passive: true });
  });
}

/** سازگاری با کدهای قبلی — دیگر همه pickerها را از نو نمی‌سازد */
function initJalaliDatePickers(scope = document) {
  bindLazyJalaliPickers(scope);
}

function refreshJalaliDatePickers() {
  // عمداً خالی: باز کردن فرم نباید ده‌ها datepicker را destroy/init کند
  bindLazyJalaliPickers(document.getElementById('personForm'));
}

/** خواندن مقدار واقعی فیلد */
function readFieldValue(el) {
  if (!el) return '';
  return (el.value || '').trim();
}

// ─── Toast ───
function toast(msg, type = 'success') {
  const el = document.getElementById('toast');
  el.className = `toast align-items-center text-white border-0 bg-${type}`;
  document.getElementById('toastBody').textContent = msg;
  bootstrap.Toast.getOrCreateInstance(el, { delay: 3000 }).show();
}

// ─── بارگذاری متادیتا و ساخت فرم‌ها ───
function bindTableEvents() {
  const table = document.getElementById('personnelTable');
  if (table && !table.dataset.bound) {
    table.dataset.bound = '1';
    table.addEventListener('click', (e) => {
      // کلیک روی چک‌باکس نباید مودال ویرایش را باز کند
      if (e.target.closest('.person-select') || e.target.matches('.person-select')) {
        return;
      }
      const btn = e.target.closest('[data-act]');
      if (btn) {
        e.stopPropagation();
        const id = Number(btn.dataset.id);
        const act = btn.dataset.act;
        if (act === 'edit') openPerson(id);
        else if (act === 'work') openWorkFor(id, btn.dataset.name || '', btn.dataset.indicator || '');
        else if (act === 'card') issueTempCard(id);
        else if (act === 'card-renew') openCardRenew(id, btn.dataset.cardType || 'temp');
        else if (act === 'card-reset') resetCardIssued(id);
        else if (act === 'del') deletePerson(id);
        return;
      }
      const tr = e.target.closest('tr[data-id]');
      if (tr) openPerson(Number(tr.dataset.id));
    });

    // تغییر چک‌باکس‌های ردیف (داخل tbody)
    table.addEventListener('change', (e) => {
      if (e.target.matches('.person-select')) {
        const id = Number(e.target.value);
        if (Number.isInteger(id)) {
          if (e.target.checked) selectedCardIds.add(id);
          else selectedCardIds.delete(id);
        }
        syncSelectAllCheckbox();
        updateGroupCardSelection();
      }
    });
  }

  // چک‌باکس «انتخاب همه» — فقط ردیف‌های صفحهٔ فعلی را انتخاب/لغو می‌کند
  const selectAll = document.getElementById('selectAllPersonnel');
  if (selectAll && !selectAll.dataset.bound) {
    selectAll.dataset.bound = '1';
    selectAll.addEventListener('change', (e) => {
      const checked = e.target.checked;
      document.querySelectorAll('#personnelTable .person-select').forEach((cb) => {
        cb.checked = checked;
        const id = Number(cb.value);
        if (!Number.isInteger(id)) return;
        if (checked) selectedCardIds.add(id);
        else selectedCardIds.delete(id);
      });
      updateGroupCardSelection();
    });
  }

  const search = document.getElementById('searchInput');
  if (search && !search.dataset.bound) {
    search.dataset.bound = '1';
    search.addEventListener('input', scheduleSearch);
    search.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { clearTimeout(_searchTimer); loadList(); }
    });
  }
}

function syncSelectAllCheckbox() {
  const selectAll = document.getElementById('selectAllPersonnel');
  if (!selectAll) return;
  const boxes = document.querySelectorAll('#personnelTable .person-select');
  if (!boxes.length) {
    selectAll.checked = false;
    selectAll.indeterminate = false;
    return;
  }
  let checkedCount = 0;
  boxes.forEach((cb) => { if (cb.checked) checkedCount++; });
  selectAll.checked = checkedCount === boxes.length;
  selectAll.indeterminate = checkedCount > 0 && checkedCount < boxes.length;
}

async function bootApp() {
  bindPageSizeControl();
  bindTableEvents();
  bindGroupCardsModalEvents();
  bindCardValidityModalEvents();
  const res = await apiFetch('/api/meta/fields');
  if (!res.ok) throw new Error('خطا در دریافت فیلدها');
  meta = await res.json();
  buildPersonForm();
  buildWorkForm();
  bindWorkEvents();
  loadList();
}

async function init() {
  try {
    const ok = await restoreSession();
    if (ok) await bootApp();
  } catch (e) {
    toast('خطا در بارگذاری: ' + e.message, 'danger');
  }
}

async function exportExcelSecure() {
  try {
    const res = await apiFetch('/api/export/excel');
    await downloadFromApiResponse(
      res,
      'خطا در خروجی اکسل',
      `personnel_export_${new Date().toISOString().slice(0, 10)}.xlsx`
    );
    toast('خروجی اکسل آماده شد');
  } catch (e) {
    toast(e.message || 'خطا در خروجی', 'danger');
  }
}

// ─── لاگ دسترسی کاربران (فقط مدیر) ───
let _accessLogsOffset = 0;
const ACCESS_LOGS_PAGE = 100;
let _accessLogsTotal = 0;
let _accessLogActionsLoaded = false;

function accessLogsModal() {
  return bootstrap.Modal.getOrCreateInstance(document.getElementById('accessLogsModal'));
}

async function openAccessLogsModal() {
  if (!isAdmin()) {
    toast('فقط مدیر به لاگ دسترسی دسترسی دارد', 'warning');
    return;
  }
  _accessLogsOffset = 0;
  accessLogsModal().show();
  await loadAccessLogs(true);
}

async function loadAccessLogs(resetOffset) {
  if (!isAdmin()) return;
  if (resetOffset) _accessLogsOffset = 0;
  const q = (document.getElementById('accessLogSearch')?.value || '').trim();
  const action = (document.getElementById('accessLogAction')?.value || '').trim();
  const params = new URLSearchParams();
  params.set('limit', String(ACCESS_LOGS_PAGE));
  params.set('offset', String(_accessLogsOffset));
  if (q) params.set('q', q);
  if (action) params.set('action', action);
  const body = document.getElementById('accessLogsBody');
  const status = document.getElementById('accessLogsStatus');
  if (body) body.innerHTML = `<tr><td colspan="5" class="text-center text-muted py-4">در حال بارگذاری...</td></tr>`;
  try {
    const res = await apiFetch(`/api/access-logs?${params.toString()}`);
    if (!res.ok) throw new Error('خطا در دریافت لاگ‌ها');
    const data = await res.json();
    _accessLogsTotal = data.total || 0;
    if (!_accessLogActionsLoaded && Array.isArray(data.actions)) {
      const sel = document.getElementById('accessLogAction');
      if (sel) {
        const current = sel.value;
        sel.innerHTML = '<option value="">همه</option>';
        data.actions.forEach((a) => {
          const opt = document.createElement('option');
          opt.value = a.key;
          opt.textContent = a.label || a.key;
          sel.appendChild(opt);
        });
        sel.value = current || '';
      }
      _accessLogActionsLoaded = true;
    }
    const items = data.items || [];
    if (!items.length) {
      if (body) body.innerHTML = `<tr><td colspan="5" class="text-center text-muted py-4">ردیفی یافت نشد</td></tr>`;
    } else if (body) {
      body.innerHTML = items.map((row) => {
        const act = esc(row.action_label || row.action || '—');
        const badgeClass =
          row.action === 'login' ? 'bg-success' :
          row.action === 'logout' ? 'bg-secondary' :
          (row.action === 'login_failed' || row.action === 'login_denied') ? 'bg-danger' :
          (row.action === 'card_issue' || row.action === 'card_renew') ? 'bg-primary' :
          'bg-dark';
        return `<tr>
          <td class="text-nowrap" dir="ltr">${esc(row.created_at || '')}</td>
          <td>${esc(row.username || '—')}</td>
          <td><span class="badge ${badgeClass}">${act}</span></td>
          <td class="small">${esc(row.detail || '')}</td>
          <td class="text-nowrap" dir="ltr">${esc(row.ip || '—')}</td>
        </tr>`;
      }).join('');
    }
    if (status) {
      const from = _accessLogsTotal ? _accessLogsOffset + 1 : 0;
      const to = Math.min(_accessLogsOffset + items.length, _accessLogsTotal);
      status.textContent = `${from.toLocaleString('fa-IR')} تا ${to.toLocaleString('fa-IR')} از ${_accessLogsTotal.toLocaleString('fa-IR')}`;
    }
    const prev = document.getElementById('accessLogsPrev');
    const next = document.getElementById('accessLogsNext');
    if (prev) prev.disabled = _accessLogsOffset <= 0;
    if (next) next.disabled = _accessLogsOffset + ACCESS_LOGS_PAGE >= _accessLogsTotal;
  } catch (e) {
    if (body) body.innerHTML = `<tr><td colspan="5" class="text-center text-danger py-4">${esc(e.message || 'خطا')}</td></tr>`;
    toast(e.message || 'خطا در بارگذاری لاگ', 'danger');
  }
}

function accessLogsPage(dir) {
  const nextOff = _accessLogsOffset + dir * ACCESS_LOGS_PAGE;
  if (nextOff < 0) return;
  if (nextOff >= _accessLogsTotal && dir > 0) return;
  _accessLogsOffset = nextOff;
  loadAccessLogs(false);
}

async function clearAccessLogs(olderThanDays) {
  if (!isAdmin()) return;
  const msg = olderThanDays
    ? `لاگ‌های قدیمی‌تر از ${olderThanDays} روز حذف شوند؟`
    : 'همه لاگ‌های دسترسی حذف شوند؟ این عمل قابل بازگشت نیست.';
  if (!confirm(msg)) return;
  try {
    const qs = olderThanDays ? `?older_than_days=${encodeURIComponent(olderThanDays)}` : '';
    const res = await apiFetch(`/api/access-logs${qs}`, { method: 'DELETE' });
    if (!res.ok) {
      let err = 'خطا در حذف لاگ';
      try { const j = await res.json(); err = j.detail || err; } catch (_) {}
      throw new Error(typeof err === 'string' ? err : JSON.stringify(err));
    }
    const data = await res.json();
    toast(data.message || 'حذف انجام شد');
    await loadAccessLogs(true);
  } catch (e) {
    toast(e.message || 'خطا در حذف', 'danger');
  }
}

// ─── مدیریت کاربران ───
function usersModal() {
  return bootstrap.Modal.getOrCreateInstance(document.getElementById('usersModal'));
}
function userFormModal() {
  return bootstrap.Modal.getOrCreateInstance(document.getElementById('userFormModal'));
}

async function openUsersModal() {
  if (!isAdmin()) {
    toast('فقط مدیر به این بخش دسترسی دارد', 'warning');
    return;
  }
  usersModal().show();
  await loadUsersTable();
}

async function loadUsersTable() {
  const tbody = document.getElementById('usersTableBody');
  tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted">در حال بارگذاری...</td></tr>';
  try {
    const res = await apiFetch('/api/users');
    if (!res.ok) throw new Error('خطا در دریافت کاربران');
    const users = await res.json();
    _usersCache = users;
    if (!users.length) {
      tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted">کاربری نیست</td></tr>';
      return;
    }
    tbody.innerHTML = users.map(u => {
      let roleBadge;
      if (u.role === 'admin') roleBadge = '<span class="badge bg-success">مدیر</span>';
      else if (u.role === 'custom') roleBadge = '<span class="badge bg-warning text-dark">سفارشی</span>';
      else roleBadge = '<span class="badge bg-secondary">عادی</span>';
      const activeBadge = u.is_active
        ? '<span class="badge bg-primary">فعال</span>'
        : '<span class="badge bg-danger">غیرفعال</span>';
      const permHint = (u.role === 'custom' && (u.permissions || []).length)
        ? `<div class="small text-muted">${(u.permissions || []).length} دسترسی</div>`
        : '';
      return `<tr>
        <td dir="ltr">${esc(u.username)}</td>
        <td>${esc(u.full_name || '—')}</td>
        <td>${roleBadge}${permHint}</td>
        <td>${activeBadge}</td>
        <td>
          <button class="btn btn-sm btn-outline-primary" onclick="openUserForm(${u.id})" title="ویرایش">
            <i class="bi bi-pencil"></i>
          </button>
          <button class="btn btn-sm btn-outline-danger" onclick="deleteUser(${u.id}, '${String(u.username).replace(/'/g, "\\'")}')" title="حذف">
            <i class="bi bi-trash"></i>
          </button>
        </td>
      </tr>`;
    }).join('');
  } catch (e) {
    tbody.innerHTML = `<tr><td colspan="5" class="text-danger">${e.message}</td></tr>`;
  }
}

function buildPermissionsCheckboxes(selected) {
  const box = document.getElementById('customPermissionsList');
  if (!box) return;
  const sel = new Set(selected || []);
  box.innerHTML = PERMISSION_DEFS.map(p => `
    <div class="col-md-6">
      <div class="form-check">
        <input class="form-check-input perm-check" type="checkbox" id="perm_${p.key}" value="${p.key}" ${sel.has(p.key) ? 'checked' : ''} />
        <label class="form-check-label" for="perm_${p.key}">${esc(p.label)}</label>
      </div>
    </div>
  `).join('');
}

function toggleCustomPermissions() {
  const role = document.getElementById('userFormRole')?.value;
  const box = document.getElementById('customPermissionsBox');
  if (!box) return;
  if (role === 'custom') {
    box.classList.remove('d-none');
    if (!document.getElementById('customPermissionsList').children.length) {
      buildPermissionsCheckboxes([]);
    }
  } else {
    box.classList.add('d-none');
  }
}

function selectAllPerms(on) {
  document.querySelectorAll('.perm-check').forEach(el => { el.checked = !!on; });
}

function collectSelectedPermissions() {
  return Array.from(document.querySelectorAll('.perm-check:checked')).map(el => el.value);
}

let _usersCache = [];
async function openUserForm(id) {
  document.getElementById('userFormId').value = id || '';
  document.getElementById('userFormUsername').value = '';
  document.getElementById('userFormFullName').value = '';
  document.getElementById('userFormRole').value = 'user';
  document.getElementById('userFormPassword').value = '';
  document.getElementById('userFormActive').checked = true;
  buildPermissionsCheckboxes([]);
  toggleCustomPermissions();
  if (id) {
    document.getElementById('userFormTitle').textContent = 'ویرایش کاربر';
    document.getElementById('userFormPasswordLabel').textContent = 'رمز عبور جدید (اختیاری)';
    document.getElementById('userFormPasswordHint').textContent = 'خالی بگذارید تا تغییر نکند';
    try {
      const res = await apiFetch('/api/users');
      const users = await res.json();
      _usersCache = users;
      const u = users.find(x => x.id === id);
      if (u) {
        document.getElementById('userFormUsername').value = u.username;
        document.getElementById('userFormFullName').value = u.full_name || '';
        document.getElementById('userFormRole').value = u.role;
        document.getElementById('userFormActive').checked = !!u.is_active;
        buildPermissionsCheckboxes(u.permissions || []);
        toggleCustomPermissions();
      }
    } catch (_) {}
  } else {
    document.getElementById('userFormTitle').textContent = 'کاربر جدید';
    document.getElementById('userFormPasswordLabel').textContent = 'رمز عبور';
    document.getElementById('userFormPasswordHint').textContent = 'حداقل ۶ کاراکتر';
  }
  userFormModal().show();
}

async function saveUserForm() {
  const id = document.getElementById('userFormId').value;
  const role = document.getElementById('userFormRole').value;
  const payload = {
    username: (document.getElementById('userFormUsername').value || '').trim(),
    full_name: (document.getElementById('userFormFullName').value || '').trim(),
    role,
    is_active: document.getElementById('userFormActive').checked,
  };
  if (role === 'custom') {
    payload.permissions = collectSelectedPermissions();
  }
  const password = document.getElementById('userFormPassword').value || '';
  if (password) payload.password = password;
  if (!id && !password) {
    toast('رمز عبور الزامی است', 'warning');
    return;
  }
  try {
    const res = await apiFetch(id ? `/api/users/${id}` : '/api/users', {
      method: id ? 'PUT' : 'POST',
      body: JSON.stringify(payload),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.detail || 'خطا در ذخیره کاربر');
    toast(data.message || 'ذخیره شد');
    userFormModal().hide();
    await loadUsersTable();
  } catch (e) {
    toast(e.message, 'danger');
  }
}

async function deleteUser(id, username) {
  if (!confirm(`کاربر «${username}» حذف شود؟`)) return;
  try {
    const res = await apiFetch(`/api/users/${id}`, { method: 'DELETE' });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.detail || 'خطا در حذف');
    toast(data.message || 'حذف شد');
    await loadUsersTable();
  } catch (e) {
    toast(e.message, 'danger');
  }
}

function buildPersonForm() {
  const form = document.getElementById('personForm');
  form.innerHTML = '';
  meta.personal.forEach((f) => {
    const col = document.createElement('div');
    col.className = f.name === 'address' || f.name === 'description' ? 'col-md-6' : 'col-md-4 col-sm-6';
    let input;
    if (f.name === 'address' || f.name === 'description') {
      input = `<textarea class="form-control form-control-sm" id="pf_${f.name}" rows="2"></textarea>`;
    } else if (f.name === 'active_status') {
      input = `<select class="form-select form-select-sm" id="pf_${f.name}">
        <option value="">نامشخص</option>
        <option value="فعال">فعال</option>
        <option value="غیرفعال">غیرفعال</option>
        <option value="مسدود">مسدود</option>
      </select>`;
    } else if (f.name === 'marital_status') {
      input = `<select class="form-select form-select-sm" id="pf_${f.name}">
        <option value="">نامشخص</option>
        <option value="مجرد">مجرد</option>
        <option value="متاهل">متاهل</option>
      </select>`;
    } else if (f.name === 'native_status') {
      input = `<select class="form-select form-select-sm" id="pf_${f.name}">
        <option value="">نامشخص</option>
        <option value="بومی">بومی</option>
        <option value="غیربومی">غیربومی</option>
      </select>`;
    } else if (f.name === 'national_id') {
      input = `<input type="text" class="form-control form-control-sm" id="pf_national_id"
        placeholder="۱۰ رقم — مثال: 0012345678" dir="ltr" inputmode="numeric"
        maxlength="10" pattern="[0-9]{10}" autocomplete="off"
        title="کد ملی باید دقیقاً ۱۰ رقم باشد" />`;
    } else {
      const isDate = isJalaliField(f);
      const ph = isDate ? 'مثال: 1403/01/15' : '';
      const dateClass = isDate ? ' jalali-date' : '';
      input = `<div class="input-group input-group-sm"><input type="text" class="form-control form-control-sm${dateClass}" id="pf_${f.name}" placeholder="${ph}" dir="ltr" autocomplete="off" />${isDate ? '<span class="input-group-text">📅</span>' : ''}</div>`;
    }
    col.innerHTML = `<label class="form-label">${f.label}</label>${input}`;
    form.appendChild(col);
  });
  bindLazyJalaliPickers(form);
  // محدود کردن ورودی کد ملی به ارقام انگلیسی (حداکثر ۱۰)
  const nidInput = document.getElementById('pf_national_id');
  if (nidInput && !nidInput.dataset.nidBound) {
    nidInput.dataset.nidBound = '1';
    nidInput.addEventListener('input', () => {
      const cleaned = toEnglishDigits(nidInput.value).replace(/\D/g, '').slice(0, 10);
      if (nidInput.value !== cleaned) nidInput.value = cleaned;
      // وقتی ۱۰ رقم کامل شد، جستجو کن
      if (cleaned.length === 10 && currentId === null) {
        lookupNationalIdForNewPerson();
      }
    });
    nidInput.addEventListener('blur', () => {
      if (currentId === null) lookupNationalIdForNewPerson();
    });
  }
}

// ─── لیست پرسنل + صفحه‌بندی ───
let _listAbort = null;
let _searchTimer = null;
let _filterTimer = null;
const FETCH_LIMIT = 5000;
/** تعداد در هر صفحه: 10 | 50 | 100 | Infinity (همه) */
let _pageSize = 50;
let _currentPage = 1;
let _personnelData = [];
let _personnelView = [];
let _personnelSort = { field: null, dir: 1 };
let _personnelDataWarned = false;
let _listTotal = 0;
/** کش سبک برای جلوگیری از fetch تکراری در مودال گروهی */
let _listCacheAt = 0;
const LIST_CACHE_MS = 15000;

function getPageSize() {
  const el = document.getElementById('pageSizeSelect');
  if (!el) return _pageSize;
  const v = el.value;
  if (v === 'all') return Infinity;
  const n = parseInt(v, 10);
  return (n === 10 || n === 50 || n === 100) ? n : 50;
}

function totalPages() {
  const n = _personnelView.length;
  if (_pageSize === Infinity || _pageSize <= 0) return 1;
  return Math.max(1, Math.ceil(n / _pageSize));
}

function goToPage(page) {
  const tp = totalPages();
  _currentPage = Math.max(1, Math.min(page, tp));
  renderPersonnelRows();
  const card = document.querySelector('.card.shadow-sm');
  if (card) {
    const top = card.getBoundingClientRect().top + window.scrollY - 70;
    if (window.scrollY > top + 80) window.scrollTo({ top, behavior: 'smooth' });
  }
}

function bindPageSizeControl() {
  const el = document.getElementById('pageSizeSelect');
  if (!el || el.dataset.bound) return;
  el.dataset.bound = '1';
  try {
    const saved = localStorage.getItem('personnelPageSize');
    if (saved && ['10', '50', '100', 'all'].includes(saved)) el.value = saved;
  } catch (_) {}
  _pageSize = getPageSize();
  el.addEventListener('change', () => {
    _pageSize = getPageSize();
    _currentPage = 1;
    try { localStorage.setItem('personnelPageSize', el.value); } catch (_) {}
    renderPersonnelRows();
  });
}

function esc(s) {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function statusBadge(status) {
  status = (status || '').trim();
  if (status === 'مسدود') return '<span class="badge bg-warning text-dark">مسدود</span>';
  if (status === 'فعال') return '<span class="badge bg-success">فعال</span>';
  if (status === 'غیرفعال') return '<span class="badge bg-secondary">غیرفعال</span>';
  if (!status || status === '—' || status === '-') return '<span class="badge bg-light text-muted border">نامشخص</span>';
  return esc(status);
}

function normalizeHeaderFilter(value) {
  return String(value ?? '').trim().toLocaleLowerCase('fa-IR');
}

function applyPersonnelHeaderFiltersAndSort(options = {}) {
  const resetPage = options.resetPage !== false; // پیش‌فرض: برو به صفحه اول
  let rows = _personnelData;
  const filters = [];
  document.querySelectorAll('.header-filter').forEach((el) => {
    const field = el.dataset.filterField;
    const value = normalizeHeaderFilter(el.value);
    if (value) filters.push({ field, value });
  });

  if (filters.length) {
    rows = rows.filter((p) => {
      for (let i = 0; i < filters.length; i++) {
        const { field, value } = filters[i];
        if (field === 'has_photo') {
          if (String(p.has_photo ? 1 : 0) !== value) return false;
        } else if (field === 'active_status' && value === '__empty__') {
          const st = String(p.active_status ?? '').trim();
          if (st && st !== '—' && st !== '-') return false;
        } else if (!normalizeHeaderFilter(p[field]).includes(value)) {
          return false;
        }
      }
      return true;
    });
  }

  if (_personnelSort.field) {
    const field = _personnelSort.field;
    const dir = _personnelSort.dir;
    rows = rows.slice();
    rows.sort((a, b) => {
      let av = a[field], bv = b[field];
      if (field === 'has_photo') { av = a.has_photo ? 1 : 0; bv = b.has_photo ? 1 : 0; }
      if (field === 'id' || field === 'row_num') {
        return ((Number(av) || 0) - (Number(bv) || 0)) * dir;
      }
      return normalizeHeaderFilter(av).localeCompare(normalizeHeaderFilter(bv), 'fa') * dir;
    });
  }

  _personnelView = rows;
  // فقط وقتی فیلتر/جستجو عوض شده به صفحه اول برو — نه بعد از ویرایش ردیف
  if (resetPage) _currentPage = 1;
  renderPersonnelRows();
}

function renderPersonnelRows() {
  const data = _personnelView;
  const tbody = document.getElementById('personnelTable');
  if (!tbody) return;

  _pageSize = getPageSize();
  const tp = totalPages();
  if (_currentPage > tp) _currentPage = tp;
  if (_currentPage < 1) _currentPage = 1;

  let start = 0;
  let end = data.length;
  if (_pageSize !== Infinity && _pageSize > 0) {
    start = (_currentPage - 1) * _pageSize;
    end = Math.min(start + _pageSize, data.length);
  }

  const slice = data.slice(start, end);
  const parts = new Array(slice.length);
  for (let i = 0; i < slice.length; i++) {
    const p = slice[i];
    const status = (p.active_status || '').trim();
    let rowClass = '';
    if (status === 'مسدود') rowClass = 'row-blocked';
    else if (status === 'غیرفعال') rowClass = 'row-inactive';
    const nameSafe = esc((p.first_name || '') + ' ' + (p.last_name || '')).replace(/'/g, '&#39;');
    const checked = selectedCardIds.has(Number(p.id)) ? ' checked' : '';
    parts[i] =
      `<tr class="${rowClass}" data-id="${p.id}">` +
      `<td class="text-center"><input type="checkbox" class="form-check-input person-select" value="${p.id}" aria-label="انتخاب ${nameSafe}" onclick="event.stopPropagation()"${checked} /></td>` +
      `<td>${p.id}</td><td>${esc(p.row_num)}</td><td>${esc(p.first_name)}</td><td>${esc(p.last_name)}</td><td>${esc(p.father_name)}</td>` +
      `<td class="col-national-id" dir="ltr" title="${esc(p.national_id)}">${esc(p.national_id)}</td>` +
      `<td class="col-indicator text-center" dir="ltr" title="${esc(p.indicator_num || '')}">${esc(p.indicator_num || '—')}</td>` +
      `<td>${statusBadge(status)}</td><td>${p.has_photo ? '📷' : '—'}</td>` +
      `<td class="text-nowrap">` +
      `<button class="btn btn-sm btn-outline-primary btn-action" title="${hasPerm('personnel_edit') ? 'ویرایش' : 'مشاهده'}" data-act="edit" data-id="${p.id}"><i class="bi bi-${hasPerm('personnel_edit') ? 'pencil' : 'eye'}"></i></button> ` +
      (() => {
        const wc = Number(p.work_count || 0);
        const title = wc > 0 ? `سوابق کاری (${wc})` : 'سوابق کاری';
        const badge = wc > 0
          ? `<span class="work-count-badge">${wc > 99 ? '99+' : wc}</span>`
          : '';
        const workBtnClass = wc > 0
          ? 'btn btn-sm btn-warning btn-action btn-work-hist has-work-history'
          : 'btn btn-sm btn-outline-info btn-action btn-work-hist';
        return `<button class="${workBtnClass}" title="${title}" data-act="work" data-id="${p.id}" data-name="${nameSafe}" data-indicator="${esc(p.indicator_num || '')}"><i class="bi bi-briefcase"></i>${badge}</button> `;
      })() +
      (hasPerm('card_issue')
        ? (() => {
            const issued = !!p.card_issued;
            const ctype = (p.card_type || (issued ? 'temp' : '') || '').trim();
            let html = '';
            if (!issued) {
              // صدور اولیه فقط وقتی هنوز کارت صادر نشده
              html += `<button class="btn btn-sm btn-outline-success btn-action" title="صدور کارت" data-act="card" data-id="${p.id}"><i class="bi bi-person-vcard"></i></button> `;
            } else if (ctype === 'one_year') {
              // کارت یکساله صادرشده: صدور مجدد ندارد (فقط نمایش وضعیت + بازنشانی مدیر)
              html += `<button class="btn btn-sm btn-action btn-card-issued-oneyear" title="کارت یکساله صادر شده — صدور مجدد مجاز نیست" data-act="card-locked" data-id="${p.id}" disabled><i class="bi bi-person-vcard"></i></button> `;
            } else {
              // کارت موقت صادرشده: فقط تمدید
              html += `<button class="btn btn-sm btn-action btn-card-issued-temp" title="کارت موقت صادر شده — برای تمدید از دکمه کنار استفاده کنید" data-act="card-locked" data-id="${p.id}" disabled><i class="bi bi-person-vcard"></i></button> `;
              html += `<button class="btn btn-sm btn-outline-warning btn-action" title="تمدید اعتبار کارت موقت" data-act="card-renew" data-id="${p.id}" data-card-type="temp"><i class="bi bi-arrow-repeat"></i></button> `;
            }
            if (issued && isAdmin()) {
              html += `<button class="btn btn-sm btn-outline-secondary btn-action" title="بازنشانی وضعیت صدور کارت (فقط مدیر)" data-act="card-reset" data-id="${p.id}"><i class="bi bi-arrow-counterclockwise"></i></button> `;
            }
            return html;
          })()
        : '') +
      (hasPerm('personnel_delete')
        ? `<button class="btn btn-sm btn-outline-danger btn-action" title="حذف" data-act="del" data-id="${p.id}"><i class="bi bi-trash"></i></button>`
        : '') +
      `</td></tr>`;
  }

  tbody.innerHTML = parts.join('') ||
    `<tr><td colspan="11" class="text-center text-muted py-4">رکوردی یافت نشد</td></tr>`;
  syncSelectAllCheckbox();
  updateGroupCardSelection();
  renderPaginationControls(start, end, data.length, tp);

  const countEl = document.getElementById('countBadge');
  if (countEl) countEl.textContent = data.length.toLocaleString('fa-IR');
  const statusEl = document.getElementById('statusText');
  if (statusEl) {
    if (!data.length) {
      statusEl.textContent = '۰ رکورد';
    } else if (_pageSize === Infinity) {
      statusEl.textContent = `${data.length.toLocaleString('fa-IR')} رکورد (همه)`;
    } else {
      statusEl.textContent =
        `${(start + 1).toLocaleString('fa-IR')}–${end.toLocaleString('fa-IR')} از ${data.length.toLocaleString('fa-IR')}`;
    }
  }
}

function renderPaginationControls(start, end, total, tp) {
  // هم نوار بالا و هم پایین به‌صورت همزمان به‌روز می‌شوند
  const targets = [
    { info: 'pageInfoTop', ul: 'paginationControlsTop', bar: 'paginationBarTop' },
    { info: 'pageInfo', ul: 'paginationControls', bar: 'paginationBar' },
  ];

  let infoText = '';
  if (!total) {
    infoText = 'رکوردی برای نمایش نیست';
  } else if (_pageSize === Infinity) {
    infoText = `نمایش همه ${total.toLocaleString('fa-IR')} نفر`;
  } else {
    infoText =
      `صفحه ${_currentPage.toLocaleString('fa-IR')} از ${tp.toLocaleString('fa-IR')} ` +
      `· ${(start + 1).toLocaleString('fa-IR')} تا ${end.toLocaleString('fa-IR')} از ${total.toLocaleString('fa-IR')}`;
  }

  let itemsHtml = '';
  if (total && _pageSize !== Infinity && tp > 1) {
    const items = [];
    const addBtn = (label, page, disabled = false, active = false, title = '') => {
      const cls = `page-item${disabled ? ' disabled' : ''}${active ? ' active' : ''}`;
      items.push(
        `<li class="${cls}">` +
        `<button type="button" class="page-link" data-page="${page}" ${disabled ? 'disabled' : ''} title="${title}">${label}</button>` +
        `</li>`
      );
    };

    addBtn('«', 1, _currentPage <= 1, false, 'صفحه اول');
    addBtn('‹', _currentPage - 1, _currentPage <= 1, false, 'صفحه قبل');

    let from = Math.max(1, _currentPage - 2);
    let to = Math.min(tp, _currentPage + 2);
    if (to - from < 4) {
      from = Math.max(1, to - 4);
      to = Math.min(tp, from + 4);
    }
    if (from > 1) {
      addBtn('1', 1, false, false);
      if (from > 2) items.push('<li class="page-item disabled"><span class="page-link">…</span></li>');
    }
    for (let p = from; p <= to; p++) {
      addBtn(p.toLocaleString('fa-IR'), p, false, p === _currentPage);
    }
    if (to < tp) {
      if (to < tp - 1) items.push('<li class="page-item disabled"><span class="page-link">…</span></li>');
      addBtn(tp.toLocaleString('fa-IR'), tp, false, false);
    }

    addBtn('›', _currentPage + 1, _currentPage >= tp, false, 'صفحه بعد');
    addBtn('»', tp, _currentPage >= tp, false, 'صفحه آخر');
    itemsHtml = items.join('');
  }

  targets.forEach(({ info, ul, bar }) => {
    const infoEl = document.getElementById(info);
    const ulEl = document.getElementById(ul);
    const barEl = document.getElementById(bar);
    if (infoEl) infoEl.textContent = infoText;
    if (ulEl) {
      ulEl.innerHTML = itemsHtml;
      ulEl.querySelectorAll('button[data-page]').forEach((btn) => {
        btn.addEventListener('click', () => {
          const p = Number(btn.dataset.page);
          if (Number.isFinite(p)) goToPage(p);
        });
      });
    }
    if (barEl) {
      if (!total) barEl.classList.add('d-none');
      else barEl.classList.remove('d-none');
    }
  });
}

function bindPersonnelHeaderControls() {
  const table = document.querySelector('.personnel-header');
  if (!table || table.dataset.bound) return;
  table.dataset.bound = '1';
  table.addEventListener('click', (e) => {
    const btn = e.target.closest('.sort-btn');
    if (!btn) return;
    const th = btn.closest('[data-sort-field]');
    if (!th) return;
    const field = th.dataset.sortField;
    _personnelSort.dir = _personnelSort.field === field ? -_personnelSort.dir : 1;
    _personnelSort.field = field;
    table.querySelectorAll('.sort-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    btn.textContent = _personnelSort.dir === 1 ? '↑' : '↓';
    applyPersonnelHeaderFiltersAndSort();
  });
  // debounce فیلتر هدر — جلوگیری از رندر در هر کلید
  table.addEventListener('input', (e) => {
    if (!e.target.matches('.header-filter')) return;
    clearTimeout(_filterTimer);
    _filterTimer = setTimeout(applyPersonnelHeaderFiltersAndSort, 150);
  });
  table.addEventListener('change', (e) => {
    if (e.target.matches('.header-filter')) applyPersonnelHeaderFiltersAndSort();
  });
}

async function loadList(force = false, options = {}) {
  const preservePage = options.preservePage === true;
  const q = document.getElementById('searchInput').value.trim();
  // استفاده از کش کوتاه‌مدت وقتی جستجو خالی است
  if (!force && !q && _personnelData.length && (Date.now() - _listCacheAt) < LIST_CACHE_MS) {
    applyPersonnelHeaderFiltersAndSort({ resetPage: false });
    return;
  }
  const url = q
    ? `/api/personnel?q=${encodeURIComponent(q)}&limit=${FETCH_LIMIT}`
    : `/api/personnel?limit=${FETCH_LIMIT}`;
  if (_listAbort) _listAbort.abort();
  _listAbort = new AbortController();
  document.getElementById('statusText').textContent = 'در حال بارگذاری...';
  try {
    const res = await apiFetch(url, { signal: _listAbort.signal });
    const payload = await res.json();
    const data = Array.isArray(payload) ? payload : (payload.items || []);
    const total = Array.isArray(payload) ? data.length : (payload.total ?? data.length);
    _personnelData = data;
    _listTotal = total;
    _listCacheAt = Date.now();
    bindPageSizeControl();
    bindPersonnelHeaderControls();
    if (!preservePage && !force && !q) {
      // بارگذاری اولیه
      _currentPage = 1;
      applyPersonnelHeaderFiltersAndSort({ resetPage: true });
    } else if (q && !preservePage) {
      _currentPage = 1;
      applyPersonnelHeaderFiltersAndSort({ resetPage: true });
    } else {
      applyPersonnelHeaderFiltersAndSort({ resetPage: false });
    }
    if (data.length < total && !_personnelDataWarned) {
      _personnelDataWarned = true;
      document.getElementById('statusText').textContent =
        `${data.length.toLocaleString('fa-IR')} از ${total.toLocaleString('fa-IR')} رکورد بارگذاری شده؛ برای فیلتر کامل‌تر جستجو کنید`;
    }
  } catch (e) {
    if (e.name === 'AbortError') return;
    toast('خطا در بارگذاری لیست', 'danger');
    document.getElementById('statusText').textContent = '';
  }
}

/** به‌روزرسانی محلی یک ردیف بدون fetch کامل لیست */
function patchPersonnelInList(id, patch) {
  const idx = _personnelData.findIndex(p => Number(p.id) === Number(id));
  if (idx >= 0) {
    Object.assign(_personnelData[idx], patch);
    _listCacheAt = Date.now();
    applyPersonnelHeaderFiltersAndSort({ resetPage: false });
    return true;
  }
  return false;
}

function removePersonnelFromList(id) {
  const before = _personnelData.length;
  _personnelData = _personnelData.filter(p => Number(p.id) !== Number(id));
  selectedCardIds.delete(Number(id));
  if (_personnelData.length !== before) {
    _listCacheAt = Date.now();
    applyPersonnelHeaderFiltersAndSort({ resetPage: false });
    return true;
  }
  return false;
}

function scheduleSearch() {
  clearTimeout(_searchTimer);
  _searchTimer = setTimeout(() => loadList(true), 220);
}

// ─── فرم شخصی ───
function setBlockedAlert(show, personName) {
  const el = document.getElementById('blockedAlert');
  if (!el) return;
  if (show) {
    el.classList.remove('d-none');
    el.style.display = 'flex';
    const namePart = personName ? ` «${personName}»` : '';
    const unlockHint = isAdmin()
      ? 'در صورت نیاز می‌توانید وضعیت را تغییر داده و ذخیره کنید.'
      : 'فقط مدیر سیستم می‌تواند این پرسنل را از مسدودی خارج کند. سایر کاربران صرفاً می‌توانند وضعیت را روی «مسدود» نگه دارند.';
    el.querySelector('div').innerHTML =
      `<strong>⚠ هشدار: وضعیت این پرسنل${namePart} «مسدود» است.</strong>` +
      `<div class="small">دسترسی یا فعالیت این فرد محدود شده است. ${unlockHint}</div>`;
  } else {
    el.classList.add('d-none');
    el.style.display = 'none';
  }
}

async function fillNextRowAndIndicator(prefix, { force = false } = {}) {
  /** prefix: 'pf_' برای فرم پرسنل، 'wf_' برای فرم سابقه */
  try {
    const res = await apiFetch('/api/meta/next-numbers');
    if (!res.ok) return null;
    const nums = await res.json();
    const rowEl = document.getElementById(prefix + 'row_num');
    const indEl = document.getElementById(prefix + 'indicator_num');
    const issueEl = document.getElementById(prefix + 'temp_issue_date');
    if (rowEl && (force || !(rowEl.value || '').trim())) rowEl.value = nums.row_num || '';
    if (indEl && (force || !(indEl.value || '').trim())) indEl.value = nums.indicator_num || '';
    // تاریخ صدور همیشه تاریخ جاری سیستم
    if (issueEl) issueEl.value = nums.temp_issue_date || '';
    return nums;
  } catch (_) {
    return null;
  }
}

/** با زدن کد ملی در فرم فرد جدید — اگر قبلاً ثبت شده، اطلاعات را پر کن */
async function lookupNationalIdForNewPerson() {
  if (currentId !== null) return; // فقط در حالت ثبت جدید
  const el = document.getElementById('pf_national_id');
  if (!el) return;
  const nid = toEnglishDigits(el.value || '').replace(/[\s\-]/g, '');
  if (!/^[0-9]{10}$/.test(nid)) return;
  el.value = nid;
  try {
    const res = await apiFetch(`/api/personnel/by-national-id/${encodeURIComponent(nid)}`);
    if (!res.ok) return;
    const p = await res.json();
    if (!p.found) return;

    // پر کردن تمام فیلدها به‌جز ردیف، اندیکاتور، تاریخ صدور
    (meta.personal || []).forEach((f) => {
      if (['row_num', 'indicator_num', 'temp_issue_date', 'national_id'].includes(f.name)) return;
      const input = document.getElementById('pf_' + f.name);
      if (!input) return;
      if (input.tagName === 'SELECT' || input.tagName === 'INPUT' || input.tagName === 'TEXTAREA') {
        input.value = p[f.name] != null ? p[f.name] : '';
      }
    });
    // اندیکاتور و ردیف جدید + تاریخ صدور جاری
    await fillNextRowAndIndicator('pf_', { force: true });
    bindLazyJalaliPickers(document.getElementById('personForm'));
    const wc = Number(p.work_count || 0);
    toast(
      `این کد ملی قبلاً ثبت شده است (${p.first_name || ''} ${p.last_name || ''} — اندیکاتور قبلی: ${p.indicator_num || '—'}` +
      (wc ? `، ${wc} سابقه` : '') +
      '). اطلاعات پر شد؛ با ذخیره، رکورد جدید اصلی می‌شود و قبلی به سابقه می‌رود.',
      'info'
    );
  } catch (e) {
    console.warn(e);
  }
}

async function openNewForm() {
  if (!hasPerm('personnel_create')) {
    toast('ثبت فرد جدید برای شما مجاز نیست', 'warning');
    return;
  }
  currentId = null;
  document.getElementById('personModalTitle').textContent = 'ثبت فرد جدید';
  const form = document.getElementById('personForm');
  meta.personal.forEach((f) => {
    const el = document.getElementById('pf_' + f.name);
    if (!el) return;
    if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT' || el.tagName === 'SELECT') el.value = '';
    el.classList.remove('is-invalid');
    el.disabled = false;
    el.style.backgroundColor = '';
  });
  bindLazyJalaliPickers(form);
  setPhotoPreview(null);
  setBlockedAlert(false);
  applyActiveStatusSelectRules(false); // همه گزینه‌های وضعیت برای رکورد جدید
  document.getElementById('btnSelectPhoto').disabled = true;
  document.getElementById('btnRemovePhoto').disabled = true;
  const saveBtn = document.querySelector('#personModal [onclick*="savePerson"]');
  if (saveBtn) saveBtn.classList.remove('d-none');
  personModal().show();
  // شماره ردیف و اندیکاتور خودکار (آخرین + ۱)
  await fillNextRowAndIndicator('pf_');
}

async function openPerson(id) {
  try {
    currentId = id;
    document.getElementById('personModalTitle').textContent = 'در حال بارگذاری...';
    personModal().show();

    const res = await apiFetch(`/api/personnel/${id}`);
    if (!res.ok) throw new Error('یافت نشد');
    const p = await res.json();
    const fullName = `${p.first_name || ''} ${p.last_name || ''}`.trim();
    const canEdit = hasPerm('personnel_edit');
    document.getElementById('personModalTitle').textContent =
      (canEdit ? 'ویرایش: ' : 'مشاهده: ') + fullName;
    meta.personal.forEach((f) => {
      const el = document.getElementById('pf_' + f.name);
      if (!el) return;
      el.value = p[f.name] || '';
      el.classList.remove('is-invalid');
      el.disabled = !canEdit;
      if (!canEdit) el.style.backgroundColor = '#f8f9fa';
      else el.style.backgroundColor = '';
    });
    bindLazyJalaliPickers(document.getElementById('personForm'));
    setPhotoPreview(p.photo ? '/' + p.photo : null);
    const canPhoto = hasPerm('photo_manage');
    const btnSel = document.getElementById('btnSelectPhoto');
    const btnRem = document.getElementById('btnRemovePhoto');
    if (btnSel) btnSel.disabled = !canPhoto;
    if (btnRem) btnRem.disabled = !canPhoto || !p.photo;
    const saveBtn = document.querySelector('#personModal [onclick*="savePerson"]');
    if (saveBtn) saveBtn.classList.toggle('d-none', !canEdit);

    const isBlocked = (p.active_status || '').trim() === 'مسدود';
    setBlockedAlert(isBlocked, fullName);

    // فقط مدیر می‌تواند وضعیت «مسدود» را به حالت دیگر تغییر دهد
    applyActiveStatusSelectRules(isBlocked);

    if (isBlocked) {
      toast(`⚠ وضعیت پرسنل «${fullName || id}» مسدود است`, 'warning');
      setTimeout(() => {
        const extra = isAdmin()
          ? ''
          : '\n\nتوجه: فقط مدیر سیستم می‌تواند این پرسنل را از مسدودی خارج کند.';
        window.alert(
          `⚠ هشدار\n\nوضعیت این پرسنل «مسدود» است.\n\nنام: ${fullName || '—'}\nکد ملی: ${p.national_id || '—'}${extra}`
        );
      }, 300);
    }
  } catch (e) {
    personModal().hide();
    toast(e.message, 'danger');
  }
}

/**
 * قوانین سلکت وضعیت فعال/غیرفعال:
 * - همه کاربران دارای ویرایش می‌توانند پرسنل را «مسدود» کنند
 * - اگر رکورد مسدود است و کاربر مدیر نیست: فقط گزینه مسدود قابل انتخاب است
 */
function applyActiveStatusSelectRules(isBlocked) {
  const sel = document.getElementById('pf_active_status');
  if (!sel || sel.tagName !== 'SELECT') return;

  const prev = sel.value;
  const canUnblock = isAdmin();

  // بازسازی گزینه‌ها
  const options = [
    { value: '', label: 'نامشخص' },
    { value: 'فعال', label: 'فعال' },
    { value: 'غیرفعال', label: 'غیرفعال' },
    { value: 'مسدود', label: 'مسدود' },
  ];
  sel.innerHTML = '';
  options.forEach((o) => {
    // غیرمدیر روی رکورد مسدود: فقط مسدود
    if (isBlocked && !canUnblock && o.value !== 'مسدود') return;
    const opt = document.createElement('option');
    opt.value = o.value;
    opt.textContent = o.label;
    sel.appendChild(opt);
  });

  if (isBlocked && !canUnblock) {
    sel.value = 'مسدود';
    sel.disabled = false; // قابل مشاهده؛ ولی فقط مسدود
    sel.title = 'فقط مدیر سیستم می‌تواند وضعیت را از مسدود خارج کند';
  } else {
    sel.value = prev;
    // اگر مقدار قبلی در گزینه‌ها نبود
    if (sel.value !== prev && prev) {
      const opt = document.createElement('option');
      opt.value = prev;
      opt.textContent = prev;
      sel.appendChild(opt);
      sel.value = prev;
    }
    sel.title = '';
  }
}

function collectPersonData() {
  const data = {};
  meta.personal.forEach((f) => {
    const el = document.getElementById('pf_' + f.name);
    data[f.name] = readFieldValue(el);
  });
  return data;
}

/** نرمال‌سازی ارقام فارسی/عربی به انگلیسی برای کد ملی */
function toEnglishDigits(s) {
  return String(s ?? '').replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d))
    .replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
}

async function savePerson() {
  const needCreate = !currentId;
  if (needCreate && !hasPerm('personnel_create')) {
    toast('ایجاد پرسنل برای شما مجاز نیست', 'warning');
    return;
  }
  if (!needCreate && !hasPerm('personnel_edit')) {
    toast('ویرایش پرسنل برای شما مجاز نیست', 'warning');
    return;
  }
  const data = collectPersonData();
  if (!data.first_name && !data.last_name) {
    toast('نام و نام خانوادگی الزامی است', 'warning');
    return;
  }

  // دفاع سمت کلاینت: غیرمدیر نتواند مسدود را بردارد (سرور هم جداگانه چک می‌کند)
  if (currentId && !isAdmin()) {
    const statusEl = document.getElementById('pf_active_status');
    const newStatus = (data.active_status || '').trim();
    const alertEl = document.getElementById('blockedAlert');
    const wasBlocked = alertEl && !alertEl.classList.contains('d-none');
    if (wasBlocked && newStatus !== 'مسدود') {
      toast('فقط مدیر سیستم می‌تواند پرسنل مسدود را از مسدودی خارج کند', 'warning');
      if (statusEl) statusEl.value = 'مسدود';
      return;
    }
  }

  // اعتبار ۲ بدون اعتبار ۱ مجاز نیست
  const v1 = (data.validity1 || '').trim();
  const v2 = (data.validity2 || '').trim();
  if (v2 && !v1) {
    toast('برای ثبت «اعتبار ۲» ابتدا باید «اعتبار ۱» وارد شود', 'warning');
    const el = document.getElementById('pf_validity1');
    if (el) { el.focus(); el.classList.add('is-invalid'); }
    return;
  }

  // اعتبارسنجی کد ملی برای رکورد جدید و ویرایش
  const nid = toEnglishDigits(data.national_id || '').replace(/[\s\-]/g, '');
  data.national_id = nid;
  if (!nid) {
    toast('کد ملی الزامی است', 'warning');
    const nidEl = document.getElementById('pf_national_id');
    if (nidEl) { nidEl.focus(); nidEl.classList.add('is-invalid'); }
    return;
  }
  if (!/^\d{10}$/.test(nid)) {
    toast('کد ملی باید دقیقاً ۱۰ رقم باشد', 'warning');
    const nidEl = document.getElementById('pf_national_id');
    if (nidEl) { nidEl.focus(); nidEl.classList.add('is-invalid'); }
    return;
  }
  const nidEl = document.getElementById('pf_national_id');
  if (nidEl) nidEl.classList.remove('is-invalid');

  try {
    let res;
    if (currentId) {
      res = await apiFetch(`/api/personnel/${currentId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
    } else {
      res = await apiFetch('/api/personnel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
    }
    const result = await res.json().catch(() => ({}));
    if (!res.ok) {
      const detail = result.detail;
      const msg = typeof detail === 'string' ? detail
        : (Array.isArray(detail) ? detail.map(d => d.msg || d).join('؛ ') : (result.message || 'خطا در ذخیره'));
      throw new Error(msg);
    }
    const wasNew = !currentId;
    if (result.id) currentId = result.id;

    if (wasNew && result.id) {
      document.getElementById('btnSelectPhoto').disabled = false;
      document.getElementById('btnRemovePhoto').disabled = true;
      document.getElementById('personModalTitle').textContent =
        `ویرایش: ${(result.first_name || data.first_name || '')} ${(result.last_name || data.last_name || '')}`.trim();

      const rowPatch = {
        id: result.id,
        row_num: result.row_num != null ? result.row_num : (data.row_num || ''),
        first_name: result.first_name || data.first_name || '',
        last_name: result.last_name || data.last_name || '',
        father_name: result.father_name || data.father_name || '',
        national_id: result.national_id || data.national_id || '',
        indicator_num: result.indicator_num != null ? result.indicator_num : (data.indicator_num || ''),
        active_status: result.active_status || data.active_status || '',
        work_count: Number(result.work_count || 0),
        has_photo: false,
      };

      if (result.promoted || result.merged) {
        // ادغام شده: ردیف موجود را به‌روز کن، تکراری نساز
        const nid = rowPatch.national_id;
        // حذف هر ردیف اضافی با همین کد ملی یا شناسه
        _personnelData = _personnelData.filter((p) => {
          if (Number(p.id) === Number(result.id)) return true;
          if (nid && String(p.national_id || '') === String(nid)) return false;
          return true;
        });
        const idx = _personnelData.findIndex((p) => Number(p.id) === Number(result.id));
        if (idx >= 0) {
          Object.assign(_personnelData[idx], rowPatch);
        } else {
          _personnelData.unshift(rowPatch);
        }
        _listCacheAt = Date.now();
        applyPersonnelHeaderFiltersAndSort({ resetPage: false });
      } else {
        // فرد کاملاً جدید
        _personnelData.unshift(rowPatch);
        _listCacheAt = Date.now();
        applyPersonnelHeaderFiltersAndSort({ resetPage: false });
      }
    } else if (currentId) {
      patchPersonnelInList(currentId, {
        row_num: data.row_num || '',
        first_name: data.first_name || '',
        last_name: data.last_name || '',
        father_name: data.father_name || '',
        national_id: data.national_id || '',
        indicator_num: data.indicator_num || '',
        active_status: data.active_status || '',
      });
    }
    // فرم را با مقادیر نهایی سرور همگام کن
    if (result.indicator_num != null) {
      const indEl = document.getElementById('pf_indicator_num');
      if (indEl) indEl.value = result.indicator_num;
      data.indicator_num = result.indicator_num;
    }
    if (result.row_num != null) {
      const rowEl = document.getElementById('pf_row_num');
      if (rowEl) rowEl.value = result.row_num;
      data.row_num = result.row_num;
    }
    meta.personal.forEach((f) => {
      const el = document.getElementById('pf_' + f.name);
      if (el && data[f.name] !== undefined) el.value = data[f.name];
    });
    toast(result.message || 'ذخیره شد');
  } catch (e) {
    toast(e.message || 'خطا در ذخیره', 'danger');
  }
}

async function deletePerson(id) {
  if (!hasPerm('personnel_delete')) {
    toast('حذف برای شما مجاز نیست', 'warning');
    return;
  }
  if (!confirm('آیا از حذف این رکورد و تمام سوابق کاری آن مطمئن هستید؟')) return;
  try {
    const res = await apiFetch(`/api/personnel/${id}`, { method: 'DELETE' });
    const result = await res.json();
    if (!res.ok) throw new Error(result.detail || 'خطا');
    toast('حذف شد');
    if (currentId === id) personModal().hide();
    if (!removePersonnelFromList(id)) loadList(true);
  } catch (e) {
    toast(e.message, 'danger');
  }
}

// ─── عکس ───
function setPhotoPreview(url) {
  const box = document.getElementById('photoPreview');
  if (url) {
    box.innerHTML = `<img src="${url}?t=${Date.now()}" alt="عکس" />`;
  } else {
    box.innerHTML = `<i class="bi bi-camera" style="font-size:2rem"></i><div class="small">بدون عکس</div>`;
  }
}

async function uploadPhoto(input) {
  if (!input.files.length) return;
  if (!currentId) {
    toast('ابتدا اطلاعات پرسنل را ذخیره کنید، سپس عکس را انتخاب کنید', 'warning');
    input.value = '';
    return;
  }
  const file = input.files[0];
  if (!file.type || !file.type.startsWith('image/')) {
    toast('فقط فایل تصویری مجاز است', 'warning');
    input.value = '';
    return;
  }
  const fd = new FormData();
  fd.append('file', file);
  try {
    const res = await apiFetch(`/api/personnel/${currentId}/photo`, { method: 'POST', body: fd });
    const result = await res.json().catch(() => ({}));
    if (!res.ok) {
      const detail = result.detail;
      throw new Error(typeof detail === 'string' ? detail : (result.message || 'خطا در آپلود عکس'));
    }
    const url = result.url || (result.photo ? '/' + result.photo : null);
    setPhotoPreview(url);
    document.getElementById('btnRemovePhoto').disabled = false;
    toast(result.message || 'عکس ذخیره شد');
    patchPersonnelInList(currentId, { has_photo: true });
  } catch (e) {
    toast(e.message || 'خطا در آپلود عکس', 'danger');
  }
  input.value = '';
}

async function removePhoto() {
  if (!currentId) return;
  if (!confirm('حذف عکس؟')) return;
  try {
    const res = await apiFetch(`/api/personnel/${currentId}/photo`, { method: 'DELETE' });
    const result = await res.json();
    if (!res.ok) throw new Error(result.detail || 'خطا');
    setPhotoPreview(null);
    document.getElementById('btnRemovePhoto').disabled = true;
    toast('عکس حذف شد');
    patchPersonnelInList(currentId, { has_photo: false });
  } catch (e) {
    toast(e.message, 'danger');
  }
}


// ─── سوابق کاری ───
function workModal() {
  return bootstrap.Modal.getOrCreateInstance(document.getElementById('workModal'));
}

function buildWorkForm() {
  const form = document.getElementById('workForm');
  if (!form || !meta.work) return;
  form.innerHTML = '';
  meta.work.forEach((f) => {
    const col = document.createElement('div');
    const isLong = f.name === 'work_description';
    col.className = isLong ? 'col-12' : 'col-md-6';
    const isDate = isJalaliField(f);
    const ph = isDate ? 'مثال: 1403/01/15' : '';
    const dateClass = isDate ? ' jalali-date' : '';
    col.innerHTML = `<label class="form-label">${esc(f.label)}</label>` +
      (isLong
        ? `<textarea class="form-control form-control-sm" id="wf_${f.name}" rows="3"></textarea>`
        : `<input type="text" class="form-control form-control-sm${dateClass}" id="wf_${f.name}" placeholder="${ph}" autocomplete="off" />`);
    form.appendChild(col);
  });
}

function clearWorkForm() {
  (meta.work || []).forEach((f) => {
    const el = document.getElementById('wf_' + f.name);
    if (el) el.value = '';
  });
  // شماره ردیف و اندیکاتور خودکار برای سابقه جدید
  fillNextRowAndIndicator('wf_');
}

function collectWorkData() {
  const data = {};
  (meta.work || []).forEach((f) => {
    const el = document.getElementById('wf_' + f.name);
    data[f.name] = el ? el.value.trim() : '';
  });
  return data;
}

function renderWorkRows(rows) {
  const tbody = document.getElementById('workTable');
  if (!tbody) return;
  if (!rows.length) {
    tbody.innerHTML = '<tr><td colspan="10" class="text-center text-muted py-3">سابقه کاری ثبت نشده است.</td></tr>';
    return;
  }
  const canPromote = hasPerm('personnel_edit') || hasPerm('work_write');
  const canWrite = hasPerm('work_write');
  tbody.innerHTML = rows.map((r) => `
    <tr data-work-id="${r.id}">
      <td>${esc(r.first_name)}${(r.indicator_num || '').trim() ? ` <span class="text-muted small" dir="ltr">(${esc(r.indicator_num)})</span>` : ''}</td>
      <td>${esc(r.last_name)}</td>
      <td class="text-center" dir="ltr" style="font-variant-numeric:tabular-nums;letter-spacing:0.02em">${esc(r.national_id || '—')}</td>
      <td class="text-center" dir="ltr" style="font-variant-numeric:tabular-nums;letter-spacing:0.02em">${esc(r.indicator_num || '—')}</td>
      <td>${esc(r.company)}</td>
      <td>${esc(r.position)}</td>
      <td>${esc(r.start_date)}</td>
      <td>${esc(r.end_date)}</td>
      <td>${esc(r.work_description)}</td>
      <td class="text-nowrap">
        ${canPromote ? `<button type="button" class="btn btn-sm btn-outline-warning" data-work-promote="${r.id}" title="جابجایی با رکورد اصلی — این سابقه رکورد اصلی شود"><i class="bi bi-arrow-left-right"></i></button> ` : ''}
        ${canWrite ? `<button type="button" class="btn btn-sm btn-outline-primary" data-work-edit="${r.id}" title="ویرایش"><i class="bi bi-pencil"></i></button> ` : ''}
        ${canWrite ? `<button type="button" class="btn btn-sm btn-outline-danger" data-work-del="${r.id}" title="حذف"><i class="bi bi-trash"></i></button>` : ''}
      </td>
    </tr>`).join('');
}

async function loadWork(id) {
  const tbody = document.getElementById('workTable');
  if (tbody) tbody.innerHTML = '<tr><td colspan="10" class="text-center text-muted py-3">در حال بارگذاری...</td></tr>';
  const res = await apiFetch(`/api/personnel/${id}/work`);
  const result = await res.json();
  if (!res.ok) throw new Error(result.detail || 'خطا در بارگذاری سوابق کاری');
  const rows = Array.isArray(result) ? result : [];
  renderWorkRows(rows);
  // به‌روزرسانی عدد روی آیکون سوابق در لیست اصلی
  syncWorkCountBadge(id, rows.length);
  return rows;
}

/** همگام‌سازی تعداد سوابق در داده لیست و دکمه ردیف */
function syncWorkCountBadge(personnelId, count) {
  const wc = Number(count) || 0;
  patchPersonnelInList(personnelId, { work_count: wc });
  // اگر ردیف الان در DOM هست، فقط دکمه را عوض کن تا صفحه نپرد
  const tr = document.querySelector(`#personnelTable tr[data-id="${personnelId}"]`);
  if (!tr) return;
  const btn = tr.querySelector('[data-act="work"]');
  if (!btn) return;
  const nameSafe = btn.dataset.name || '';
  const ind = btn.dataset.indicator || '';
  const title = wc > 0 ? `سوابق کاری (${wc})` : 'سوابق کاری';
  const badge = wc > 0
    ? `<span class="work-count-badge">${wc > 99 ? '99+' : wc}</span>`
    : '';
  const workBtnClass = wc > 0
    ? 'btn btn-sm btn-warning btn-action btn-work-hist has-work-history'
    : 'btn btn-sm btn-outline-info btn-action btn-work-hist';
  btn.className = workBtnClass;
  btn.title = title;
  btn.innerHTML = `<i class="bi bi-briefcase"></i>${badge}`;
}

async function openWorkFor(id, name, indicator) {
  try {
    currentWorkId = id;
    selectedWorkId = null;
    let ind = (indicator || '').trim();
    let titleName = (name || '').trim() || 'پرسنل';
    // اگر اندیکاتور از دکمه نیامد، از رکورد اصلی بگیر
    if (!ind || titleName === 'پرسنل') {
      try {
        const res = await apiFetch(`/api/personnel/${id}`);
        if (res.ok) {
          const p = await res.json();
          if (!ind) ind = (p.indicator_num || '').trim();
          if (!name || titleName === 'پرسنل') {
            titleName = `${p.first_name || ''} ${p.last_name || ''}`.trim() || titleName;
          }
        }
      } catch (_) {}
    }
    document.getElementById('workModalTitle').textContent = ind
      ? `سوابق کاری: ${titleName} | اندیکاتور ${ind}`
      : `سوابق کاری: ${titleName}`;
    buildWorkForm();
    clearWorkForm();
    bindLazyJalaliPickers(document.getElementById('workForm'));
    workModal().show();
    await loadWork(id);
  } catch (e) {
    console.error(e);
    toast(e.message || 'خطا در بارگذاری سوابق کاری', 'danger');
  }
}

async function saveWork() {
  if (!currentWorkId) return;
  const data = collectWorkData();
  if (!data.company) {
    toast('نام شرکت الزامی است', 'warning');
    return;
  }
  try {
    const url = selectedWorkId ? `/api/work/${selectedWorkId}` : `/api/personnel/${currentWorkId}/work`;
    const res = await apiFetch(url, {
      method: selectedWorkId ? 'PUT' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const result = await res.json();
    if (!res.ok) throw new Error(result.detail || 'خطا در ذخیره سابقه کاری');
    toast(result.message || 'سابقه کاری ذخیره شد');
    selectedWorkId = null;
    clearWorkForm();
    bindLazyJalaliPickers(document.getElementById('workForm'));
    await loadWork(currentWorkId);
  } catch (e) {
    toast(e.message || 'خطا در ذخیره سابقه کاری', 'danger');
  }
}

async function editWork(id) {
  try {
    const res = await apiFetch(`/api/personnel/${currentWorkId}/work`);
    const rows = await res.json();
    if (!res.ok) throw new Error(rows.detail || 'خطا');
    const row = rows.find((x) => Number(x.id) === Number(id));
    if (!row) throw new Error('سابقه یافت نشد');
    selectedWorkId = id;
    (meta.work || []).forEach((f) => {
      const el = document.getElementById('wf_' + f.name);
      if (el) el.value = row[f.name] || '';
    });
    bindLazyJalaliPickers(document.getElementById('workForm'));
    document.getElementById('btnCancelWorkEdit').classList.remove('d-none');
    document.getElementById('btnSaveWork').innerHTML = '<i class="bi bi-check2"></i> بروزرسانی سابقه';
  } catch (e) {
    toast(e.message || 'خطا در انتخاب سابقه', 'danger');
  }
}

function cancelWorkEdit() {
  selectedWorkId = null;
  clearWorkForm();
  document.getElementById('btnCancelWorkEdit').classList.add('d-none');
  document.getElementById('btnSaveWork').innerHTML = '<i class="bi bi-plus-lg"></i> افزودن سابقه';
  bindLazyJalaliPickers(document.getElementById('workForm'));
}

async function deleteWork(id) {
  if (!confirm('آیا از حذف این سابقه کاری مطمئن هستید؟')) return;
  try {
    const res = await apiFetch(`/api/work/${id}`, { method: 'DELETE' });
    const result = await res.json();
    if (!res.ok) throw new Error(result.detail || 'خطا در حذف سابقه');
    if (selectedWorkId === id) cancelWorkEdit();
    toast(result.message || 'حذف شد');
    await loadWork(currentWorkId);
  } catch (e) {
    toast(e.message || 'خطا در حذف سابقه کاری', 'danger');
  }
}

async function promoteWork(id) {
  if (!hasPerm('personnel_edit') && !hasPerm('work_write')) {
    toast('شما به جابجایی سابقه با رکورد اصلی دسترسی ندارید', 'warning');
    return;
  }
  if (!confirm(
    'آیا مطمئن هستید؟\n\n' +
    '• این سابقه به «رکورد اصلی» تبدیل می‌شود\n' +
    '• رکورد اصلی فعلی به «سابقه» منتقل می‌شود\n\n' +
    'عکس پرسنلی روی رکورد اصلی باقی می‌ماند.'
  )) return;
  try {
    const res = await apiFetch(`/api/work/${id}/promote`, { method: 'POST' });
    const result = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(result.detail || 'خطا در جابجایی');
    toast(result.message || 'جابجایی انجام شد', 'success');
    if (selectedWorkId === id) cancelWorkEdit();
    await loadWork(currentWorkId);
    // لیست اصلی پرسنل را تازه کن تا اندیکاتور/وضعیت جدید دیده شود
    try { await loadList(true, { preservePage: true }); } catch (_) {}
  } catch (e) {
    toast(e.message || 'خطا در جابجایی سابقه با رکورد اصلی', 'danger');
  }
}

function bindWorkEvents() {
  const tbody = document.getElementById('workTable');
  if (!tbody || tbody.dataset.bound) return;
  tbody.dataset.bound = '1';
  tbody.addEventListener('click', (e) => {
    const promote = e.target.closest('[data-work-promote]');
    if (promote) return promoteWork(Number(promote.dataset.workPromote));
    const edit = e.target.closest('[data-work-edit]');
    if (edit) return editWork(Number(edit.dataset.workEdit));
    const del = e.target.closest('[data-work-del]');
    if (del) return deleteWork(Number(del.dataset.workDel));
  });
}


async function mergeHistories() {
  if (!isAdmin()) {
    toast('فقط مدیر می‌تواند ادغام سوابق را اجرا کند', 'warning');
    return;
  }
  if (!confirm(
    'ادغام سابقه با رکورد اصلی\n\n' +
    '• کدهای ملی تکراری پیدا می‌شوند\n' +
    '• رکورد با اندیکاتور جدیدتر به‌عنوان اصلی می‌ماند\n' +
    '• رکوردهای بدون اندیکاتور (قدیمی) اندیکاتور می‌گیرند و به سابقه می‌روند\n\n' +
    'ادامه می‌دهید؟'
  )) return;
  try {
    toast('در حال ادغام...', 'info');
    const res = await apiFetch('/api/admin/merge-histories', { method: 'POST' });
    const result = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(result.detail || 'خطا در ادغام');
    toast(result.message || 'ادغام انجام شد', 'success');
    try { await loadList(true, { preservePage: true }); } catch (_) {}
  } catch (e) {
    toast(e.message || 'خطا در ادغام سوابق', 'danger');
  }
}

// ─── ایمپورت اکسل ───
async function importExcel(input) {
  if (!input.files.length) return;
  const fd = new FormData();
  fd.append('file', input.files[0]);
  try {
    toast('در حال بررسی و ایمپورت...', 'info');
    const res = await apiFetch('/api/import/excel', { method: 'POST', body: fd });
    const result = await res.json();
    if (!res.ok) {
      const detail = result.detail;
      if (detail && typeof detail === 'object') {
        const lines = [detail.message || 'خطا در ایمپورت'];
        (detail.errors || []).slice(0, 50).forEach((x) => {
          lines.push(`ردیف ${x.row} — ${x.field}: ${x.value}`);
        });
        if (detail.total_errors > 50) lines.push(`... و ${detail.total_errors - 50} خطای دیگر`);
        const message = lines.join('\n');
        toast(detail.message || 'تاریخ‌های نامعتبر پیدا شد', 'danger');
        window.alert(message + '\n\nلطفاً تاریخ‌های مشخص‌شده را در فایل Excel اصلاح کرده و دوباره ایمپورت کنید.');
      } else {
        const message = detail || 'خطا در ایمپورت';
        toast(message, 'danger');
        window.alert(message);
      }
      return;
    }
    toast(result.message || 'ایمپورت انجام شد');
    loadList(true);
  } catch (e) {
    toast(e.message || 'خطا در ارتباط با سرور', 'danger');
  } finally {
    input.value = '';
  }
}


// ─── انتخاب پرسنل برای تولید گروهی کارت ───
let groupCardPersonnel = [];
let groupCardSelectedIds = new Set();
let _groupCardsSearchTimer = null;

function groupCardsModal() {
  return bootstrap.Modal.getOrCreateInstance(document.getElementById('groupCardsModal'));
}

function getSelectedPersonnelIds() {
  return Array.from(document.querySelectorAll('#personnelTable .person-select:checked'))
    .map(cb => Number(cb.value))
    .filter(Number.isInteger);
}

function updateGroupCardSelection() {
  const mainIds = getSelectedPersonnelIds();
  const badge = document.getElementById('selectedCardsBadge');
  // انتخاب‌های جدول اصلی فقط برای پیش‌انتخاب در مودال استفاده می‌شوند.
  if (badge) badge.textContent = mainIds.length || groupCardSelectedIds.size;
}

function normalizeDigits(text) {
  return String(text ?? '').replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d));
}

function getFilteredGroupCardPersonnel() {
  const q = (document.getElementById('groupCardsSearch')?.value || '').trim().toLocaleLowerCase();
  const qDigits = normalizeDigits(q);
  return groupCardPersonnel.filter(p => {
    if (!q) return true;
    const fullName = `${p.first_name || ''} ${p.last_name || ''}`.toLocaleLowerCase();
    const father = String(p.father_name || '').toLocaleLowerCase();
    const nid = normalizeDigits(p.national_id || '');
    return fullName.includes(q) || father.includes(q) || nid.includes(qDigits);
  });
}

// برای جلوگیری از کندی شدید، فقط بخشی از ردیف‌ها وارد DOM می‌شوند.
// کل فهرست در حافظه باقی می‌ماند و انتخاب‌ها از بین نمی‌روند.
const GROUP_CARDS_RENDER_LIMIT = 150;

function renderGroupCardsTable() {
  const tbody = document.getElementById('groupCardsTable');
  if (!tbody) return;

  const filtered = getFilteredGroupCardPersonnel();
  const visible = filtered.slice(0, GROUP_CARDS_RENDER_LIMIT);

  const rows = visible.map(p => {
    const id = Number(p.id);
    const checked = groupCardSelectedIds.has(id);
    const fullName = `${p.first_name || ''} ${p.last_name || ''}`.trim() || '—';
    const status = (p.active_status || '').trim();
    const rowClass = checked ? 'group-card-selected' : '';
    return `<tr class="${rowClass}" data-group-card-id="${id}">
      <td class="text-center">
        <input type="checkbox" class="form-check-input group-card-select"
               value="${id}" ${checked ? 'checked' : ''}
               aria-label="انتخاب ${esc(fullName)}" />
      </td>
      <td>${esc(p.id)}</td>
      <td>${esc(fullName)}</td>
      <td>${esc(p.father_name)}</td>
      <td dir="ltr">${esc(p.national_id)}</td>
      <td>${statusBadge(status)}</td>
      <td class="text-center">${p.has_photo ? '📷' : '—'}</td>
    </tr>`;
  });

  tbody.innerHTML = rows.join('') ||
    `<tr><td colspan="7" class="text-center text-muted py-4">پرسنلی مطابق جستجو پیدا نشد.</td></tr>`;

  const countEl = document.getElementById('groupCardsListStatus');
  if (countEl) {
    const totalText = filtered.length.toLocaleString('fa-IR');
    const shownText = visible.length.toLocaleString('fa-IR');
    countEl.textContent = filtered.length > visible.length
      ? `${shownText} نفر نمایش داده شد — از ${totalText} نتیجه؛ برای جستجوی دقیق‌تر جستجو کنید`
      : `${totalText} نفر`;
  }

  updateGroupCardsModalCount(filtered);
}

function updateGroupCardsModalCount(visibleRows = null) {
  const count = groupCardSelectedIds.size;
  const text = `${count.toLocaleString('fa-IR')} نفر انتخاب شده`;
  const countEl = document.getElementById('groupCardsSelectedCount');
  const footerEl = document.getElementById('groupCardsFooterCount');
  const badge = document.getElementById('selectedCardsBadge');
  const generateBtn = document.getElementById('btnGenerateSelectedCards');
  if (countEl) countEl.textContent = text;
  if (footerEl) footerEl.textContent = count.toLocaleString('fa-IR');
  if (badge) badge.textContent = count.toLocaleString('fa-IR');
  if (generateBtn) generateBtn.disabled = count === 0;

  const selectVisible = document.getElementById('groupCardsSelectAllVisible');
  if (selectVisible) {
    const ids = (visibleRows || groupCardPersonnel).map(p => Number(p.id));
    const selectedVisible = ids.filter(id => groupCardSelectedIds.has(id));
    selectVisible.checked = ids.length > 0 && selectedVisible.length === ids.length;
    selectVisible.indeterminate = selectedVisible.length > 0 && selectedVisible.length < ids.length;
  }
}

async function openGroupCardsModal() {
  groupCardSelectedIds = new Set(getSelectedPersonnelIds());

  const tbody = document.getElementById('groupCardsTable');
  document.getElementById('groupCardsListStatus').textContent = '';
  document.getElementById('groupCardsSearch').value = '';
  groupCardsModal().show();

  // استفاده از کش لیست اصلی اگر تازه باشد — بدون fetch دوباره
  const cacheFresh = _personnelData.length && (Date.now() - _listCacheAt) < LIST_CACHE_MS * 4;
  if (cacheFresh) {
    groupCardPersonnel = _personnelData.slice();
    const validIds = new Set(groupCardPersonnel.map(p => Number(p.id)));
    groupCardSelectedIds = new Set(
      Array.from(groupCardSelectedIds).filter(id => validIds.has(id))
    );
    renderGroupCardsTable();
    return;
  }

  if (tbody) {
    tbody.innerHTML =
      '<tr><td colspan="7" class="text-center py-4 text-muted"><span class="spinner-border spinner-border-sm me-2"></span>در حال بارگذاری لیست پرسنل...</td></tr>';
  }

  try {
    const res = await apiFetch('/api/personnel?limit=5000');
    const payload = await res.json();
    if (!res.ok) throw new Error(payload.detail || 'خطا در دریافت لیست پرسنل');
    groupCardPersonnel = Array.isArray(payload) ? payload : (payload.items || []);
    // همگام‌سازی کش اصلی
    if (!_personnelData.length) {
      _personnelData = groupCardPersonnel.slice();
      _listCacheAt = Date.now();
    }
    const validIds = new Set(groupCardPersonnel.map(p => Number(p.id)));
    groupCardSelectedIds = new Set(
      Array.from(groupCardSelectedIds).filter(id => validIds.has(id))
    );
    renderGroupCardsTable();
  } catch (e) {
    if (tbody) {
      tbody.innerHTML =
        `<tr><td colspan="7" class="text-center text-danger py-4">${esc(e.message || 'خطا در بارگذاری لیست')}</td></tr>`;
    }
    toast(e.message || 'خطا در بارگذاری لیست پرسنل', 'danger');
  }
}

function selectAllVisibleGroupCards(checked) {
  const filtered = getFilteredGroupCardPersonnel();
  filtered.forEach(p => {
    const id = Number(p.id);
    if (checked) groupCardSelectedIds.add(id);
    else groupCardSelectedIds.delete(id);
  });

  // فقط چک‌باکس‌های حاضر در DOM را به‌روزرسانی کن؛ از بازسازی هزاران ردیف جلوگیری می‌شود.
  document.querySelectorAll('#groupCardsTable .group-card-select').forEach(cb => {
    cb.checked = checked;
    const tr = cb.closest('tr[data-group-card-id]');
    if (tr) tr.classList.toggle('group-card-selected', checked);
  });
  updateGroupCardsModalCount(filtered);
}

function bindGroupCardsModalEvents() {
  const modal = document.getElementById('groupCardsModal');
  if (!modal || modal.dataset.bound) return;
  modal.dataset.bound = '1';

  const tbody = document.getElementById('groupCardsTable');
  tbody.addEventListener('change', (e) => {
    const cb = e.target.closest('.group-card-select');
    if (!cb) return;
    const id = Number(cb.value);
    if (cb.checked) groupCardSelectedIds.add(id);
    else groupCardSelectedIds.delete(id);
    // مهم: هنگام انتخاب یک نفر کل ۵۰۰۰ ردیف دوباره ساخته نشود.
    const tr = cb.closest('tr[data-group-card-id]');
    if (tr) tr.classList.toggle('group-card-selected', cb.checked);
    updateGroupCardsModalCount(getFilteredGroupCardPersonnel());
  });

  tbody.addEventListener('click', (e) => {
    const tr = e.target.closest('tr[data-group-card-id]');
    if (!tr || e.target.closest('input')) return;
    const cb = tr.querySelector('.group-card-select');
    if (cb) {
      cb.checked = !cb.checked;
      cb.dispatchEvent(new Event('change', { bubbles: true }));
    }
  });

  document.getElementById('btnSelectAllGroupCards').addEventListener('click', () => {
    selectAllVisibleGroupCards(true);
  });
  document.getElementById('btnClearAllGroupCards').addEventListener('click', () => {
    selectAllVisibleGroupCards(false);
  });
  document.getElementById('groupCardsSelectAllVisible').addEventListener('change', (e) => {
    selectAllVisibleGroupCards(e.target.checked);
  });

  const search = document.getElementById('groupCardsSearch');
  search.addEventListener('input', () => {
    clearTimeout(_groupCardsSearchTimer);
    _groupCardsSearchTimer = setTimeout(renderGroupCardsTable, 120);
  });
  document.getElementById('btnClearGroupCardsSearch').addEventListener('click', () => {
    search.value = '';
    renderGroupCardsTable();
    search.focus();
  });
}

/** وضعیت مودال تاریخ اعتبار کارت (تکی یا گروهی) */
let _cardValidityContext = null; // { mode: 'single'|'group', id?: number }

function cardValidityModal() {
  return bootstrap.Modal.getOrCreateInstance(document.getElementById('cardValidityModal'));
}

function bindCardValidityModalEvents() {
  const modalEl = document.getElementById('cardValidityModal');
  if (!modalEl || modalEl.dataset.bound === '1') return;
  modalEl.dataset.bound = '1';

  const modeDate = document.getElementById('validityModeDate');
  const modeMonths = document.getElementById('validityModeMonths');
  const dateInput = document.getElementById('cardValidityDate');
  const monthsInput = document.getElementById('cardValidityMonths');
  const issueToday = document.getElementById('issueDateModeToday');
  const issueCustom = document.getElementById('issueDateModeCustom');
  const issueInput = document.getElementById('cardIssueDate');

  function syncIssueMode() {
    const isCustom = issueCustom.checked;
    issueInput.disabled = !isCustom;
    if (isCustom) {
      setTimeout(() => issueInput.focus(), 30);
    }
  }

  function syncValidityMode() {
    const isMonths = modeMonths.checked;
    monthsInput.disabled = !isMonths;
    dateInput.disabled = isMonths;
    if (isMonths) {
      monthsInput.focus();
    } else {
      dateInput.focus();
    }
  }

  issueToday.addEventListener('change', syncIssueMode);
  issueCustom.addEventListener('change', syncIssueMode);
  modeDate.addEventListener('change', syncValidityMode);
  modeMonths.addEventListener('change', syncValidityMode);

  document.getElementById('btnConfirmCardValidity').addEventListener('click', () => {
    confirmCardValidityAndGenerate();
  });

  modalEl.addEventListener('shown.bs.modal', () => {
    bindLazyJalaliPickers(modalEl);
    ensureJalaliPicker(dateInput);
    ensureJalaliPicker(issueInput);
    syncIssueMode();
    syncValidityMode();
    // فوکوس پیش‌فرض روی تعداد ماه
    if (modeMonths.checked) {
      setTimeout(() => monthsInput.focus(), 50);
    }
  });
}

function openCardValidityPrompt(context) {
  _cardValidityContext = context;
  // پیش‌فرض: تاریخ صدور = جاری سیستم
  document.getElementById('issueDateModeToday').checked = true;
  document.getElementById('issueDateModeCustom').checked = false;
  document.getElementById('cardIssueDate').value = '';
  document.getElementById('cardIssueDate').disabled = true;
  // پیش‌فرض: تعداد ماه پس از تاریخ صدور
  document.getElementById('validityModeMonths').checked = true;
  document.getElementById('validityModeDate').checked = false;
  document.getElementById('cardValidityDate').value = '';
  document.getElementById('cardValidityMonths').value = '';
  document.getElementById('cardIsOneYear').checked = false;
  document.getElementById('cardValidityMonths').disabled = false;
  document.getElementById('cardValidityDate').disabled = true;
  cardValidityModal().show();
}

/** تبدیل ارقام فارسی/عربی به انگلیسی و نرمال‌سازی جداکننده تاریخ */
function toLatinDigits(str) {
  if (str == null) return '';
  const map = {
    '۰': '0', '۱': '1', '۲': '2', '۳': '3', '۴': '4',
    '۵': '5', '۶': '6', '۷': '7', '۸': '8', '۹': '9',
    '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4',
    '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9',
  };
  return String(str).replace(/[۰-۹٠-٩]/g, ch => map[ch] || ch);
}

function parseJalaliInput(raw, label) {
  let text = toLatinDigits((raw || '').trim()).replace(/[-.]/g, '/').replace(/\s+/g, '');
  if (!text) {
    toast(`${label} را وارد کنید`, 'warning');
    return null;
  }
  const parts = text.split('/');
  if (parts.length !== 3 || !parts.every(p => /^\d+$/.test(p))) {
    toast(`فرمت ${label} باید YYYY/MM/DD باشد (مثال 1405/06/31)`, 'warning');
    return null;
  }
  let [y, m, d] = parts.map(p => parseInt(p, 10));
  if (y < 100) y = y <= 95 ? 1400 + y : 1300 + y;
  if (!(y >= 1200 && y <= 1600) || m < 1 || m > 12 || d < 1 || d > 31) {
    toast(`${label} نامعتبر است`, 'warning');
    return null;
  }
  return `${y}/${String(m).padStart(2, '0')}/${String(d).padStart(2, '0')}`;
}

function readCardValidityOptions() {
  const isDateMode = document.getElementById('validityModeDate').checked;
  const isOneYear = document.getElementById('cardIsOneYear').checked;
  const isCustomIssue = document.getElementById('issueDateModeCustom').checked;
  let issueDate = null;
  let validityDate = null;
  let months = null;

  // تاریخ صدور
  if (isCustomIssue) {
    issueDate = parseJalaliInput(
      document.getElementById('cardIssueDate').value,
      'تاریخ صدور'
    );
    if (!issueDate) return null;
  }

  // تاریخ اعتبار
  if (isDateMode) {
    validityDate = parseJalaliInput(
      document.getElementById('cardValidityDate').value,
      'تاریخ اعتبار'
    );
    if (!validityDate) return null;
  } else {
    const raw = toLatinDigits((document.getElementById('cardValidityMonths').value || '').trim());
    if (!raw) {
      toast('تعداد ماه پس از تاریخ صدور را وارد کنید', 'warning');
      return null;
    }
    months = parseInt(raw, 10);
    if (!Number.isFinite(months) || months < 1 || months > 120) {
      toast('تعداد ماه باید عددی بین ۱ تا ۱۲۰ باشد', 'warning');
      return null;
    }
  }
  return { issueDate, validityDate, months, isOneYear };
}

async function confirmCardValidityAndGenerate() {
  const opts = readCardValidityOptions();
  if (!opts || !_cardValidityContext) return;

  cardValidityModal().hide();

  if (_cardValidityContext.mode === 'single') {
    await doIssueTempCard(_cardValidityContext.id, opts);
  } else if (_cardValidityContext.mode === 'group') {
    await doIssueGroupCards(opts);
  }
  _cardValidityContext = null;
}

async function issueGroupCards() {
  const ids = Array.from(groupCardSelectedIds);
  if (!ids.length) {
    toast('حداقل یک پرسنل را برای صدور کارت انتخاب کنید', 'warning');
    return;
  }
  if (ids.length > 1000) {
    toast('حداکثر ۱۰۰۰ پرسنل در هر نوبت قابل تولید است', 'warning');
    return;
  }
  openCardValidityPrompt({ mode: 'group' });
}

async function doIssueGroupCards(opts) {
  const ids = Array.from(groupCardSelectedIds);
  if (!ids.length) {
    toast('حداقل یک پرسنل را برای صدور کارت انتخاب کنید', 'warning');
    return;
  }

  const btn = document.getElementById('btnGenerateSelectedCards');
  if (btn) {
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>در حال تولید...';
  }
  toast(`در حال تولید کارت ${ids.length.toLocaleString('fa-IR')} پرسنل...`, 'info');

  try {
    const body = {
      ids,
      is_one_year: !!opts.isOneYear,
    };
    if (opts.issueDate) body.issue_date = opts.issueDate;
    if (opts.validityDate) body.validity_date = opts.validityDate;
    if (opts.months != null) body.months = opts.months;

    const res = await apiFetch('/api/personnel/cards/group', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });

    await downloadFromApiResponse(
      res,
      'خطا در تولید کارت‌های گروهی',
      `group_cards_${new Date().toISOString().slice(0, 19).replace(/[-:T]/g, '')}.pdf`
    );

    // به‌روزرسانی رنگ آیکون کارت برای همه افراد این نوبت
    const gType = opts && opts.isOneYear ? 'one_year' : 'temp';
    ids.forEach((id) => patchPersonnelInList(id, { card_issued: true, card_type: gType }));

    const pages = Math.ceil(ids.length / 4);
    toast(`${ids.length.toLocaleString('fa-IR')} کارت تولید شد؛ ${pages.toLocaleString('fa-IR')} برگه A4`);
    groupCardsModal().hide();
  } catch (e) {
    toast(e.message || 'خطا در تولید کارت‌های گروهی', 'danger');
    console.error(e);
  } finally {
    if (btn) {
      btn.disabled = groupCardSelectedIds.size === 0;
      btn.innerHTML = '<i class="bi bi-printer"></i> تولید کارت‌های انتخاب‌شده <span id="groupCardsFooterCount" class="badge bg-light text-dark ms-1"></span>';
    }
    updateGroupCardsModalCount();
  }
}

// ─── صدور کارت تردد موقت ───
async function issueTempCard(id) {
  // اگر قبلاً صادر شده باشد، صدور مجدد مجاز نیست
  const row = (_personnelData || []).find((p) => Number(p.id) === Number(id));
  if (row && row.card_issued) {
    toast(
      row.card_type === 'one_year'
        ? 'کارت یکساله این پرسنل قبلاً صادر شده است. صدور مجدد فقط پس از بازنشانی توسط مدیر ممکن است.'
        : 'کارت موقت این پرسنل قبلاً صادر شده است. از دکمه تمدید اعتبار استفاده کنید.',
      'warning'
    );
    return;
  }
  openCardValidityPrompt({ mode: 'single', id: Number(id) });
}

async function doIssueTempCard(id, opts) {
  toast('در حال تولید کارت...', 'info');
  try {
    const params = new URLSearchParams();
    if (opts.issueDate) params.set('issue_date', opts.issueDate);
    if (opts.validityDate) params.set('validity_date', opts.validityDate);
    if (opts.months != null) params.set('months', String(opts.months));
    if (opts.isOneYear) params.set('is_one_year', 'true');
    const qs = params.toString();
    const url = `/api/personnel/${id}/card` + (qs ? `?${qs}` : '');

    const res = await apiFetch(url);
    await downloadFromApiResponse(res, 'خطا در تولید کارت', `card_${id}.pdf`);
    const cType = opts && opts.isOneYear ? 'one_year' : 'temp';
    patchPersonnelInList(id, { card_issued: true, card_type: cType });
    toast('کارت PDF دانلود شد');
  } catch (e) {
    toast(e.message || 'خطا در دانلود کارت', 'danger');
    console.error(e);
  }
}

/** بازنشانی فلگ صدور کارت — فقط مدیر (رنگ آیکون به حالت اولیه) */
async function resetCardIssued(id) {
  if (!isAdmin()) {
    toast('فقط مدیر سیستم می‌تواند وضعیت صدور کارت را بازنشانی کند', 'warning');
    return;
  }
  if (!confirm('رنگ/وضعیت «کارت صادر شده» برای این پرسنل به حالت اولیه برگردد؟')) {
    return;
  }
  try {
    const res = await apiFetch(`/api/personnel/${id}/card-issued/reset`, { method: 'POST' });
    if (!res.ok) {
      let msg = 'خطا در بازنشانی';
      try {
        const err = await res.json();
        msg = err.detail || msg;
      } catch (_) {}
      throw new Error(typeof msg === 'string' ? msg : JSON.stringify(msg));
    }
    patchPersonnelInList(id, { card_issued: false, card_type: '' });
    toast('وضعیت صدور کارت بازنشانی شد');
  } catch (e) {
    toast(e.message || 'خطا در بازنشانی', 'danger');
  }
}

/** مودال تمدید اعتبار کارت صادرشده */
function cardRenewModal() {
  return bootstrap.Modal.getOrCreateInstance(document.getElementById('cardRenewModal'));
}

async function openCardRenew(id, cardType) {
  const ctype = (cardType === 'one_year') ? 'one_year' : 'temp';
  if (ctype === 'one_year') {
    toast('تمدید اعتبار برای کارت یکساله مجاز نیست', 'warning');
    return;
  }
  const idNum = Number(id);
  const titleEl = document.getElementById('cardRenewModalTitle');
  const tempBox = document.getElementById('cardRenewTempFields');
  const yearBox = document.getElementById('cardRenewOneYearFields');
  const prevAlert = document.getElementById('cardRenewPrevAlert');
  const prevValEl = document.getElementById('cardRenewPrevDateValue');
  const help1 = document.getElementById('cardRenewExt1Help');
  const help2 = document.getElementById('cardRenewExt2Help');
  if (titleEl) titleEl.textContent = 'تمدید اعتبار کارت موقت';
  if (tempBox) tempBox.classList.remove('d-none');
  if (yearBox) yearBox.classList.add('d-none');
  document.getElementById('cardRenewId').value = String(idNum);
  document.getElementById('cardRenewType').value = 'temp';
  const e1 = document.getElementById('cardRenewExt1');
  const e2 = document.getElementById('cardRenewExt2');
  if (e1) {
    e1.value = '';
    lockDateField(e1, false); // باز کردن قفل برای حالت پیش‌فرض
  }
  if (e2) e2.value = '';
  if (prevAlert) prevAlert.classList.add('d-none');
  if (help1) help1.textContent = 'الزامی — در کادر بالای پشت کارت درج می‌شود و مبنای تاریخ اعتبار روی کارت است (اگر تمدید ۲ خالی باشد).';
  if (help2) help2.textContent = 'اختیاری — فقط وقتی تمدید ۱ وارد شده باشد در کادر پایین چاپ می‌شود و در آن صورت تاریخ اعتبار روی کارت همین تاریخ است.';

  // بارگذاری تاریخ اعتبار ۱ قبلی (در صورت وجود) تا کاربر بداند کارت قبلاً یک‌بار تمدید شده
  try {
    const res = await apiFetch(`/api/personnel/${idNum}`);
    if (res.ok) {
      const person = await res.json();
      const prevV1 = (person.validity1 || '').trim();
      if (prevV1 && prevV1 !== '—') {
        if (prevAlert) prevAlert.classList.remove('d-none');
        if (prevValEl) prevValEl.textContent = prevV1;
        if (e1) {
          e1.value = prevV1;
          lockDateField(e1, true); // قفل کامل: disabled + بدون تقویم
        }
        if (help1) help1.textContent = 'از تمدید قبلی — در کادر بالای پشت کارت حفظ می‌شود و قابل تغییر نیست.';
        if (help2) help2.textContent = 'الزامی — تاریخ تمدید جدید؛ در کادر پایین پشت کارت چاپ می‌شود و تاریخ اعتبار روی کارت همین تاریخ خواهد بود.';
      }
    }
  } catch (err) {
    console.warn('بارگذاری اعتبار قبلی ناموفق:', err);
  }

  // فعال‌سازی تقویم جلالی فقط روی فیلدهای غیرقفل
  bindLazyJalaliPickers(document.getElementById('cardRenewModal'));
  cardRenewModal().show();
}

async function confirmCardRenew() {
  const id = Number(document.getElementById('cardRenewId').value);
  if (!id) {
    toast('شناسه پرسنل نامعتبر است', 'warning');
    return;
  }
  const e1El = document.getElementById('cardRenewExt1');
  const e1 = (e1El?.value || '').trim();
  const e2 = (document.getElementById('cardRenewExt2').value || '').trim();
  // اگر اعتبار ۱ قفل شده (تمدید قبلی)، تمدید ۲ الزامی است
  const e1Locked = !!(e1El && (e1El.dataset.locked === '1' || e1El.disabled || e1El.readOnly));
  if (e1Locked) {
    if (!e1) {
      toast('تاریخ تمدید قبلی یافت نشد', 'warning');
      return;
    }
    if (!e2) {
      toast('تاریخ تمدید اعتبار ۲ (جدید) الزامی است', 'warning');
      return;
    }
  } else if (!e1) {
    toast('تاریخ تمدید اعتبار ۱ الزامی است', 'warning');
    return;
  }
  const body = { extension1: e1 };
  if (e2) body.extension2 = e2;
  const btn = document.getElementById('btnConfirmCardRenew');
  if (btn) {
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>در حال تولید...';
  }
  toast('در حال تولید کارت تمدیدی...', 'info');
  try {
    const res = await apiFetch(`/api/personnel/${id}/card/renew`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    await downloadFromApiResponse(res, 'خطا در تمدید کارت', `card_renew_${id}.pdf`);
    patchPersonnelInList(id, { card_issued: true, card_type: 'temp' });
    cardRenewModal().hide();
    toast('کارت تمدیدی دانلود شد');
  } catch (e) {
    toast(e.message || 'خطا در تمدید کارت', 'danger');
    console.error(e);
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.innerHTML = '<i class="bi bi-printer"></i> تولید کارت تمدیدی';
    }
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const btn = document.getElementById('btnConfirmCardRenew');
  if (btn && !btn.dataset.bound) {
    btn.dataset.bound = '1';
    btn.addEventListener('click', () => { confirmCardRenew(); });
  }
});

// شروع
document.addEventListener('DOMContentLoaded', init);
